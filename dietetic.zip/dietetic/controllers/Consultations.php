<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Consultations extends AdminController
{
    public function __construct()
    {
        parent::__construct();

        // Load Perfex models
        $this->load->model('clients_model');
        $this->load->model('staff_model');

        // Load dietetic models
        $this->load->model('dietetic/dietetic_consultations_model');
        $this->load->model('dietetic/dietetic_patients_model');
        $this->load->model('dietetic/dietetic_availability_model');
        $this->load->helper('dietetic/dietetic');

        if (!dietetic_has_permission('view')) {
            access_denied('dietetic');
        }
    }

    /**
     * List all consultations
     */
    public function index()
    {
        $data['title'] = _l('dietetic_consultations');

        // Pagination configuration
        $per_page = 20; // Nombre de consultations par page
        $page = $this->input->get('page') ? (int)$this->input->get('page') : 1;
        $offset = ($page - 1) * $per_page;

        // Get filter status from GET parameter
        $status = $this->input->get('status');
        $where = [];

        if ($status && $status !== 'all') {
            $where['cons.status'] = $status;
        }

        // Count total consultations
        $total_consultations = $this->dietetic_consultations_model->count_all($where);

        // Get consultations for current page
        $data['consultations'] = $this->dietetic_consultations_model->get_all($where, $per_page, $offset);

        // Pagination data
        $data['total_consultations'] = $total_consultations;
        $data['per_page'] = $per_page;
        $data['current_page'] = $page;
        $data['total_pages'] = ceil($total_consultations / $per_page);
        $data['status_filter'] = $status;

        $this->load->view('admin/consultations/list', $data);
    }

    /**
     * View consultation detail
     *
     * @param int $id
     */
    public function view($id)
    {
        $data['consultation'] = $this->dietetic_consultations_model->get($id);

        if (!$data['consultation']) {
            show_404();
        }

        $data['title'] = _l('dietetic_consultation') . ' #' . $id;
        $data['patient'] = $this->dietetic_patients_model->get($data['consultation']->patient_id);

        // Get primary contact for patient
        $this->load->model('dietetic/dietetic_notifications_model');
        $data['primary_contact'] = $this->dietetic_notifications_model->get_client_primary_contact($data['patient']->client_id);

        $this->load->view('admin/consultations/view', $data);
    }

    /**
     * Create new consultation
     */
    public function create()
    {
        if (!dietetic_has_permission('create')) {
            access_denied('dietetic');
        }

        if ($this->input->post()) {
            $data = $this->input->post();

            // Remove fields that don't exist in database
            unset($data['height_patient']); // Used only for BMI calculation in form

            // Set dietitian if not set
            if (!isset($data['dietitian_id'])) {
                $data['dietitian_id'] = get_staff_user_id();
            }

            // Set default duration
            if (!isset($data['duration']) || empty($data['duration'])) {
                $data['duration'] = dietetic_get_option('default_consultation_duration', 60);
            }

            // Check availability before creating consultation
            if (isset($data['consultation_date']) && isset($data['dietitian_id'])) {
                $availability_check = $this->dietetic_availability_model->check_availability(
                    $data['dietitian_id'],
                    $data['consultation_date'],
                    $data['duration']
                );

                if (!$availability_check['available']) {
                    set_alert('warning', '⚠️ Attention : ' . $availability_check['reason']);
                    // Continue anyway but warn the user
                }
            }

            $consultation_id = $this->dietetic_consultations_model->add($data);

            if ($consultation_id) {
                // Send notification to patient
                try {
                    if ($this->db->table_exists(db_prefix() . 'dietic_notification_preferences') && isset($data['patient_id'])) {
                        $this->load->model('dietetic/dietetic_notifications_model');

                        // Get consultation info
                        $consultation = $this->dietetic_consultations_model->get($consultation_id);

                        // Get dietitian info
                        $dietitian_id = $data['dietitian_id'] ?? get_staff_user_id();
                        $dietitian = $this->staff_model->get($dietitian_id);
                        $dietitian_name = $dietitian ? ($dietitian->firstname . ' ' . $dietitian->lastname) : 'Votre diététicien';

                        // Send notification
                        $this->dietetic_notifications_model->notify_consultation_scheduled(
                            $data['patient_id'],
                            $data['consultation_date'],
                            $data['consultation_time'] ?? null,
                            $dietitian_name,
                            $data['consultation_type'] ?? 'Consultation'
                        );
                    }
                } catch (Exception $e) {
                    log_activity('Consultation notification error: ' . $e->getMessage());
                }

                set_alert('success', _l('added_successfully'));
                redirect(admin_url('dietetic/consultations/view/' . $consultation_id));
            } else {
                set_alert('danger', _l('dietetic_error_add_failed'));
            }
        }

        $data['title'] = _l('dietetic_new_consultation');

        // Get patients
        $data['patients'] = $this->dietetic_patients_model->get_all();

        // Get staff members
        $data['staff'] = $this->staff_model->get();

        // Get consultation types
        $data['consultation_types'] = $this->dietetic_availability_model->get_consultation_types();

        $this->load->view('admin/consultations/form', $data);
    }

    /**
     * Edit consultation
     *
     * @param int $id
     */
    public function edit($id)
    {
        if (!dietetic_has_permission('edit')) {
            access_denied('dietetic');
        }

        $data['consultation'] = $this->dietetic_consultations_model->get($id);

        if (!$data['consultation']) {
            show_404();
        }

        if ($this->input->post()) {
            $update_data = $this->input->post();

            // Remove fields that don't exist in database
            unset($update_data['height_patient']); // Used only for BMI calculation in form

            // Check availability if date/time changed
            $date_changed = isset($update_data['consultation_date']) &&
                          $update_data['consultation_date'] != $data['consultation']->consultation_date;
            $dietitian_changed = isset($update_data['dietitian_id']) &&
                               $update_data['dietitian_id'] != $data['consultation']->dietitian_id;

            if (($date_changed || $dietitian_changed) && isset($update_data['consultation_date'])) {
                $dietitian_id = $update_data['dietitian_id'] ?? $data['consultation']->dietitian_id;
                $duration = $update_data['duration'] ?? $data['consultation']->duration;

                $availability_check = $this->dietetic_availability_model->check_availability(
                    $dietitian_id,
                    $update_data['consultation_date'],
                    $duration,
                    $id // Exclude current consultation
                );

                if (!$availability_check['available']) {
                    set_alert('warning', '⚠️ Attention : ' . $availability_check['reason']);
                    // Continue anyway but warn the user
                }
            }

            // Check if consultation was cancelled
            $was_cancelled = (isset($update_data['status']) &&
                             $update_data['status'] == 'cancelled' &&
                             $data['consultation']->status != 'cancelled');

            if ($this->dietetic_consultations_model->update($id, $update_data)) {
                // Send appropriate notification
                try {
                    if ($this->db->table_exists(db_prefix() . 'dietic_notification_preferences') && $data['consultation']->patient_id) {
                        $this->load->model('dietetic/dietetic_notifications_model');

                        // Get dietitian info
                        $dietitian = $this->staff_model->get($data['consultation']->dietitian_id);
                        $dietitian_name = $dietitian ? ($dietitian->firstname . ' ' . $dietitian->lastname) : 'Votre diététicien';

                        if ($was_cancelled) {
                            // Notify cancellation
                            $this->dietetic_notifications_model->notify_consultation_cancelled(
                                $data['consultation']->patient_id,
                                $data['consultation']->consultation_date,
                                $dietitian_name,
                                $update_data['cancellation_reason'] ?? ''
                            );
                        } else {
                            // Notify modification (date/time changed)
                            $date_changed = isset($update_data['consultation_date']) &&
                                          $update_data['consultation_date'] != $data['consultation']->consultation_date;
                            $time_changed = isset($update_data['consultation_time']) &&
                                          $update_data['consultation_time'] != $data['consultation']->consultation_time;

                            if ($date_changed || $time_changed) {
                                $this->dietetic_notifications_model->notify_consultation_scheduled(
                                    $data['consultation']->patient_id,
                                    $update_data['consultation_date'] ?? $data['consultation']->consultation_date,
                                    $update_data['consultation_time'] ?? $data['consultation']->consultation_time,
                                    $dietitian_name,
                                    $update_data['consultation_type'] ?? $data['consultation']->consultation_type
                                );
                            }
                        }
                    }
                } catch (Exception $e) {
                    log_activity('Consultation update notification error: ' . $e->getMessage());
                }

                set_alert('success', _l('updated_successfully'));
                redirect(admin_url('dietetic/consultations/view/' . $id));
            } else {
                set_alert('danger', _l('dietetic_error_update_failed'));
            }
        }

        $data['title'] = _l('dietetic_edit_consultation');

        // Get patients
        $data['patients'] = $this->dietetic_patients_model->get_all();

        // Get staff members
        $data['staff'] = $this->staff_model->get();

        // Get consultation types
        $data['consultation_types'] = $this->dietetic_availability_model->get_consultation_types();

        $this->load->view('admin/consultations/form', $data);
    }

    /**
     * Delete consultation (POST avec CSRF)
     *
     * @param int $id
     */
    public function delete($id = null)
    {
        if (!dietetic_has_permission('delete')) {
            access_denied('dietetic');
        }

        // Récupérer l'ID depuis POST si non fourni dans l'URL
        if ($id === null) {
            $id = $this->input->post('consultation_id');
        }

        if (!$id) {
            set_alert('danger', 'ID de consultation manquant');
            redirect(admin_url('dietetic/consultations'));
            return;
        }

        // Vérifier que la requête est bien en POST (CSRF automatiquement vérifié par CodeIgniter)
        if ($this->input->post()) {
            if ($this->dietetic_consultations_model->delete($id)) {
                set_alert('success', 'Consultation supprimée avec succès');
            } else {
                set_alert('danger', 'Erreur lors de la suppression de la consultation');
            }
        } else {
            set_alert('warning', 'Méthode non autorisée');
        }

        // Rediriger vers la page des consultations avec les filtres
        $status = $this->input->post('status_filter') ?? 'all';
        $page = $this->input->post('current_page') ?? 1;
        redirect(admin_url('dietetic/consultations?status=' . $status . '&page=' . $page));
    }

    /**
     * Get consultations for calendar view
     */
    public function calendar()
    {
        $data['title'] = _l('dietetic_consultation_calendar');

        $this->load->view('admin/consultations/calendar', $data);
    }

    /**
     * Get consultations for FullCalendar
     */
    public function get_calendar_data()
    {
        $start = $this->input->get('start');
        $end = $this->input->get('end');

        $consultations = $this->dietetic_consultations_model->get_by_date_range($start, $end);

        $events = [];

        foreach ($consultations as $consultation) {
            $color = '#28a745'; // green for scheduled

            if ($consultation->status == 'completed') {
                $color = '#007bff'; // blue
            } elseif ($consultation->status == 'cancelled') {
                $color = '#dc3545'; // red
            } elseif ($consultation->status == 'no_show') {
                $color = '#ffc107'; // yellow
            }

            $events[] = [
                'id'              => $consultation->id,
                'title'           => $consultation->client_name,
                'start'           => $consultation->consultation_date,
                'end'             => date('Y-m-d H:i:s', strtotime($consultation->consultation_date . ' +' . $consultation->duration . ' minutes')),
                'backgroundColor' => $color,
                'borderColor'     => $color,
                'url'             => admin_url('dietetic/consultations/view/' . $consultation->id),
            ];
        }

        echo json_encode($events);
    }

    /**
     * Mark consultation as completed
     *
     * @param int $id
     */
    public function mark_completed($id)
    {
        if (!dietetic_has_permission('edit')) {
            ajax_access_denied();
        }

        if ($this->dietetic_consultations_model->update($id, ['status' => 'completed'])) {
            echo json_encode(['success' => true, 'message' => _l('dietetic_consultation_marked_completed')]);
        } else {
            echo json_encode(['success' => false, 'message' => _l('dietetic_error_update_failed')]);
        }
    }

    /**
     * Accept a patient appointment request
     */
    public function accept_appointment($id)
    {
        if (!dietetic_has_permission('edit')) {
            ajax_access_denied();
        }

        $consultation = $this->dietetic_consultations_model->get($id);

        if (!$consultation || $consultation->status != 'pending') {
            echo json_encode(['success' => false, 'message' => 'Demande introuvable ou déjà traitée']);
            return;
        }

        if ($this->dietetic_consultations_model->update($id, ['status' => 'scheduled'])) {
            log_activity('Patient appointment request accepted [Consultation ID: ' . $id . ']');

            // Send multi-channel notification to patient
            try {
                $this->load->model('dietetic/dietetic_notifications_model');
                $result = $this->dietetic_notifications_model->notify_appointment_accepted(
                    $id,
                    $consultation->patient_id,
                    $consultation->consultation_date,
                    $consultation->dietitian_name,
                    ucfirst(str_replace('_', ' ', $consultation->consultation_type))
                );

                // Log notification results
                if ($result) {
                    $channels_sent = [];
                    if (!empty($result['email'])) $channels_sent[] = 'Email';
                    if (!empty($result['sms'])) $channels_sent[] = 'SMS';
                    if (!empty($result['whatsapp'])) $channels_sent[] = 'WhatsApp';
                    if (!empty($result['push'])) $channels_sent[] = 'Push';

                    log_activity('Appointment accepted notifications sent [' . implode(', ', $channels_sent) . '] to patient ID ' . $consultation->patient_id);
                }
            } catch (Exception $e) {
                log_message('error', 'Failed to send appointment accepted notification: ' . $e->getMessage());
            }

            echo json_encode(['success' => true, 'message' => 'Demande de rendez-vous acceptée']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erreur lors de l\'acceptation']);
        }
    }

    /**
     * Reject a patient appointment request
     */
    public function reject_appointment($id)
    {
        if (!dietetic_has_permission('edit')) {
            access_denied('dietetic');
        }

        $reason = $this->input->post('reason');
        $consultation = $this->dietetic_consultations_model->get($id);

        if (!$consultation || $consultation->status != 'pending') {
            set_alert('danger', 'Demande introuvable ou déjà traitée');
            redirect(admin_url('dietetic/consultations/view/' . $id));
        }

        $update_data = ['status' => 'rejected'];
        if ($reason) {
            $update_data['notes'] = ($consultation->notes ? $consultation->notes . "\n\n" : '') .
                                     "Refusé par le diététicien: " . $reason;
        }

        if ($this->dietetic_consultations_model->update($id, $update_data)) {
            log_activity('Patient appointment request rejected [Consultation ID: ' . $id . ']');

            // Send multi-channel notification to patient
            try {
                $this->load->model('dietetic/dietetic_notifications_model');
                $result = $this->dietetic_notifications_model->notify_appointment_rejected(
                    $id,
                    $consultation->patient_id,
                    $consultation->consultation_date,
                    $consultation->dietitian_name,
                    $reason ?? ''
                );

                // Log notification results
                if ($result) {
                    $channels_sent = [];
                    if (!empty($result['email'])) $channels_sent[] = 'Email';
                    if (!empty($result['sms'])) $channels_sent[] = 'SMS';
                    if (!empty($result['whatsapp'])) $channels_sent[] = 'WhatsApp';
                    if (!empty($result['push'])) $channels_sent[] = 'Push';

                    log_activity('Appointment rejected notifications sent [' . implode(', ', $channels_sent) . '] to patient ID ' . $consultation->patient_id);
                }
            } catch (Exception $e) {
                log_message('error', 'Failed to send appointment rejected notification: ' . $e->getMessage());
            }

            set_alert('success', 'Demande de rendez-vous refusée avec succès. Le patient a été notifié par SMS, Email et WhatsApp.');
            redirect(admin_url('dietetic/consultations/view/' . $id));
        } else {
            set_alert('danger', 'Erreur lors du refus de la demande');
            redirect(admin_url('dietetic/consultations/view/' . $id));
        }
    }

    /**
     * API: Check availability for a consultation
     * Used for real-time validation in the consultation form
     */
    public function check_availability()
    {
        header('Content-Type: application/json');

        $dietitian_id = $this->input->get('dietitian_id') ?? $this->input->post('dietitian_id');
        $datetime = $this->input->get('datetime') ?? $this->input->post('datetime');
        $duration = $this->input->get('duration') ?? $this->input->post('duration') ?? 60;
        $consultation_id = $this->input->get('consultation_id') ?? $this->input->post('consultation_id');

        if (!$dietitian_id || !$datetime) {
            echo json_encode([
                'success' => false,
                'message' => 'Paramètres manquants'
            ]);
            return;
        }

        // Check availability
        $result = $this->dietetic_availability_model->check_availability(
            $dietitian_id,
            $datetime,
            $duration,
            $consultation_id
        );

        // If not available, get alternative slots for the same day and next 3 days
        $alternative_slots = [];
        if (!$result['available']) {
            $date = date('Y-m-d', strtotime($datetime));

            // Check current day and next 3 days
            for ($i = 0; $i < 4; $i++) {
                $check_date = date('Y-m-d', strtotime($date . ' +' . $i . ' days'));
                $slots = $this->dietetic_availability_model->get_available_slots(
                    $dietitian_id,
                    $check_date,
                    null,
                    $duration,
                    $consultation_id
                );

                if (!empty($slots)) {
                    foreach ($slots as $slot) {
                        $alternative_slots[] = [
                            'datetime' => $slot['datetime'], // Already in correct format
                            'display_date' => $this->format_french_date($check_date),
                            'display_time' => $slot['start_time'] // Use start_time instead of time
                        ];

                        // Limit to 6 alternative slots
                        if (count($alternative_slots) >= 6) {
                            break 2;
                        }
                    }
                }
            }
        }

        echo json_encode([
            'success' => true,
            'available' => $result['available'],
            'reason' => $result['reason'],
            'conflicts' => $result['conflicts'],
            'alternative_slots' => $alternative_slots
        ]);
    }

    /**
     * Format date in French
     */
    private function format_french_date($date)
    {
        $days = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
        $months = ['', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

        $timestamp = strtotime($date);
        $day_name = $days[date('w', $timestamp)];
        $day = date('d', $timestamp);
        $month = $months[date('n', $timestamp)];

        return $day_name . ' ' . $day . ' ' . $month;
    }
}

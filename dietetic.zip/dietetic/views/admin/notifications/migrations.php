<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>

<script>
// Define CSRF tokens globally for JavaScript
var csrf_token_name = '<?php echo $this->security->get_csrf_token_name(); ?>';
var csrf_hash_name = '<?php echo $this->security->get_csrf_hash(); ?>';
</script>

<style>
.migrations-container {
    max-width: 1200px;
    margin: 30px auto;
    padding: 0 20px;
}

.migrations-header {
    text-align: center;
    margin-bottom: 40px;
}

.migrations-header h1 {
    color: #01807B;
    font-size: 32px;
    margin-bottom: 10px;
}

.migrations-header p {
    color: #718096;
    font-size: 16px;
}

.migrations-grid {
    display: grid;
    gap: 20px;
    margin-bottom: 30px;
}

.migration-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    overflow: hidden;
    transition: all 0.3s ease;
}

.migration-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.15);
}

.migration-card-header {
    padding: 20px;
    background: linear-gradient(135deg, #01807B 0%, #026660 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.migration-card-header h3 {
    margin: 0;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.migration-status {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.migration-status.pending {
    background: #fef5e7;
    color: #d68910;
}

.migration-status.completed {
    background: #d5f4e6;
    color: #0e6655;
}

.migration-status.error {
    background: #fadbd8;
    color: #943126;
}

.migration-card-body {
    padding: 20px;
}

.migration-description {
    color: #4a5568;
    margin-bottom: 15px;
    line-height: 1.6;
}

.migration-tables {
    background: #f7fafc;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 15px;
}

.migration-tables h4 {
    color: #2d3748;
    font-size: 14px;
    margin: 0 0 10px 0;
}

.migration-tables ul {
    margin: 0;
    padding-left: 20px;
}

.migration-tables li {
    color: #718096;
    font-size: 13px;
    margin-bottom: 4px;
}

.migration-tables code {
    background: #e2e8f0;
    padding: 2px 6px;
    border-radius: 3px;
    font-family: 'Courier New', monospace;
    font-size: 12px;
}

.migration-card-footer {
    padding: 15px 20px;
    background: #f7fafc;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.migration-meta {
    color: #718096;
    font-size: 13px;
}

.migration-actions {
    display: flex;
    gap: 10px;
}

.btn-migrate {
    padding: 8px 20px;
    background: #01807B;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 6px;
}

.btn-migrate:hover {
    background: #026660;
}

.btn-migrate:disabled {
    background: #cbd5e0;
    cursor: not-allowed;
}

.btn-check {
    padding: 8px 20px;
    background: #718096;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
}

.btn-check:hover {
    background: #4a5568;
}

.global-actions {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    margin-bottom: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.global-actions h3 {
    margin: 0;
    color: #2d3748;
    font-size: 18px;
}

.global-buttons {
    display: flex;
    gap: 10px;
}

.btn-primary-large {
    padding: 12px 30px;
    background: linear-gradient(135deg, #01807B 0%, #026660 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.btn-primary-large:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 15px rgba(1, 128, 123, 0.3);
}

.btn-primary-large:disabled {
    background: #cbd5e0;
    cursor: not-allowed;
    transform: none;
}

.btn-secondary-large {
    padding: 12px 30px;
    background: white;
    color: #01807B;
    border: 2px solid #01807B;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
}

.btn-secondary-large:hover {
    background: #f7fafc;
}

.alert-box {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: none;
}

.alert-box.success {
    background: #d5f4e6;
    border-left: 4px solid #0e6655;
    color: #0e6655;
}

.alert-box.error {
    background: #fadbd8;
    border-left: 4px solid #943126;
    color: #943126;
}

.alert-box.info {
    background: #d6eaf8;
    border-left: 4px solid #1f618d;
    color: #1f618d;
}

.progress-bar {
    width: 100%;
    height: 4px;
    background: #e2e8f0;
    border-radius: 2px;
    overflow: hidden;
    margin-top: 10px;
    display: none;
}

.progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #01807B 0%, #026660 100%);
    width: 0%;
    transition: width 0.3s ease;
}
</style>

<div id="wrapper">
    <div class="content">
        <div class="migrations-container">
            <!-- Header -->
            <div class="migrations-header">
                <h1>
                    <i class="fa fa-database"></i>
                    Migrations Système de Notifications
                </h1>
                <p>Installez et gérez les migrations SQL pour le système de notifications complet</p>
            </div>

            <!-- Alert Box -->
            <div id="alertBox" class="alert-box"></div>

            <!-- Global Actions -->
            <div class="global-actions">
                <h3>Actions groupées</h3>
                <div class="global-buttons">
                    <button id="checkAllBtn" class="btn-secondary-large" onclick="checkAllMigrations()">
                        <i class="fa fa-search"></i>
                        Vérifier tout
                    </button>
                    <button id="runAllBtn" class="btn-primary-large" onclick="runAllMigrations()">
                        <i class="fa fa-rocket"></i>
                        Tout installer
                    </button>
                </div>
            </div>

            <!-- Progress Bar -->
            <div class="progress-bar" id="progressBar">
                <div class="progress-bar-fill" id="progressBarFill"></div>
            </div>

            <!-- Migrations Grid -->
            <div class="migrations-grid">
                <!-- Migration 0: LAM SMS Config Update (CRITICAL FIX) -->
                <div class="migration-card" data-migration="lam_update" style="border: 2px solid #f39c12;">
                    <div class="migration-card-header" style="background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);">
                        <h3>
                            <i class="fa fa-wrench"></i>
                            🔧 Mise à jour LAM SMS (IMPORTANT)
                        </h3>
                        <span class="migration-status pending" id="status-lam_update">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            <strong>Migration corrective nécessaire :</strong> Met à jour la configuration LAM SMS vers le nouveau format avec accountid + password.
                            Corrige l'erreur "Duplicate entry 'lam_api_url'" et remplace les anciens paramètres obsolètes.
                        </div>
                        <div class="migration-tables">
                            <h4>Actions :</h4>
                            <ul>
                                <li>🗑️ Suppression des anciens paramètres : <code>lam_api_url</code>, <code>lam_api_key</code>, <code>sms_lam_api_key</code></li>
                                <li>✅ Ajout des nouveaux paramètres : <code>sms_lam_account_id</code>, <code>sms_lam_password</code></li>
                                <li>✅ Ajout de : <code>sms_lam_ret_url</code>, <code>sms_lam_priority</code></li>
                                <li>✅ Mise à jour du sender_id par défaut : <code>API_LAMSMS</code></li>
                            </ul>
                        </div>
                        <div class="alert alert-warning" style="margin-top: 15px; background: #fff3cd; border-left: 4px solid #f39c12; padding: 10px;">
                            <i class="fa fa-exclamation-triangle"></i>
                            <strong>Important :</strong> Cette migration est requise si vous aviez déjà installé le système de notifications avant le 11 novembre 2025.
                            Elle ne supprime aucune donnée, seulement les clés de configuration obsolètes.
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> update_lam_sms_config.sql
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('lam_update')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('lam_update')" style="background: #f39c12;">
                                <i class="fa fa-wrench"></i> Appliquer le correctif
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 1: Base Notifications -->
                <div class="migration-card" data-migration="notifications">
                    <div class="migration-card-header">
                        <h3>
                            <i class="fa fa-bell"></i>
                            Système de Notifications de Base
                        </h3>
                        <span class="migration-status pending" id="status-notifications">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            Installation du système de notifications complet avec préférences patients, logs, jalons et paramètres SMS/WhatsApp.
                        </div>
                        <div class="migration-tables">
                            <h4>Tables créées :</h4>
                            <ul>
                                <li><code>tbldietic_notification_preferences</code> - Préférences par patient</li>
                                <li><code>tbldietic_notification_logs</code> - Historique notifications</li>
                                <li><code>tbldietic_milestones</code> - Jalons atteints</li>
                                <li><code>tbldietic_notification_settings</code> - Configuration globale</li>
                            </ul>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_notifications_system.sql
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('notifications')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('notifications')">
                                <i class="fa fa-play"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 2: Firebase Push -->
                <div class="migration-card" data-migration="firebase">
                    <div class="migration-card-header">
                        <h3>
                            <i class="fa fa-mobile"></i>
                            Notifications Push Firebase
                        </h3>
                        <span class="migration-status pending" id="status-firebase">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            Ajout du support des notifications push via Firebase Cloud Messaging. Permet d'envoyer des notifications instantanées sur web et mobile.
                        </div>
                        <div class="migration-tables">
                            <h4>Ajouts :</h4>
                            <ul>
                                <li><code>tbldietic_fcm_tokens</code> - Tokens Firebase par appareil</li>
                                <li><code>channel_push</code> - Nouveau canal dans preferences</li>
                                <li><code>push</code> - Nouveau type dans notification_logs</li>
                                <li>Paramètres Firebase dans settings</li>
                            </ul>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_firebase_push_notifications.sql
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('firebase')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('firebase')">
                                <i class="fa fa-play"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 3: Performance Optimizations -->
                <div class="migration-card" data-migration="optimizations">
                    <div class="migration-card-header">
                        <h3>
                            <i class="fa fa-tachometer"></i>
                            Optimisations Performance
                        </h3>
                        <span class="migration-status pending" id="status-optimizations">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            Ajout d'index composites pour améliorer les performances des requêtes fréquentes. Accélère les recherches et les statistiques.
                        </div>
                        <div class="migration-tables">
                            <h4>Index ajoutés :</h4>
                            <ul>
                                <li><code>idx_patient_created</code> - Logs par patient et date</li>
                                <li><code>idx_status_created</code> - Recherche par statut</li>
                                <li><code>idx_patient_active</code> - Tokens FCM actifs</li>
                                <li><code>idx_reminder_weight</code> - Rappels de pesée</li>
                                <li>+ 6 autres index de performance</li>
                            </ul>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> optimize_notifications_performance.sql
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('optimizations')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('optimizations')">
                                <i class="fa fa-play"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 4: Staff Permissions System -->
                <div class="migration-card" data-migration="permissions">
                    <div class="migration-card-header">
                        <h3>
                            <i class="fa fa-shield"></i>
                            Système de Permissions Granulaires
                        </h3>
                        <span class="migration-status pending" id="status-permissions">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            Système de permissions granulaires permettant de contrôler l'accès de chaque diététicien aux différentes fonctionnalités (Enquêtes alimentaires, Gestion notifications, etc.)
                        </div>
                        <div class="migration-tables">
                            <h4>Ajouts :</h4>
                            <ul>
                                <li><code>tbldietic_staff_permissions</code> - Permissions par diététicien</li>
                                <li>Paramètres par défaut pour nouvelles permissions</li>
                                <li>Support permissions : food_surveys, notifications_manage, reports_advanced, settings_module</li>
                                <li>Permissions par défaut pour staff existants</li>
                            </ul>
                        </div>
                        <div class="alert alert-info" style="margin-top: 15px;">
                            <i class="fa fa-info-circle"></i>
                            <strong>Important :</strong> Après installation, gérez les permissions via <strong>Diététique > Permissions Diététiciens</strong>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_staff_permissions.sql
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('permissions')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('permissions')">
                                <i class="fa fa-play"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 5: Firebase v1 API Support -->
                <div class="migration-card" data-migration="firebase_v1" style="border: 2px solid #4285F4;">
                    <div class="migration-card-header" style="background: linear-gradient(135deg, #4285F4 0%, #3367D6 100%);">
                        <h3>
                            <i class="fa fa-rocket"></i>
                            🆕 Firebase Cloud Messaging API v1
                        </h3>
                        <span class="migration-status pending" id="status-firebase_v1">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            <strong>Migration vers l'API moderne Firebase v1 :</strong> Ajoute le support de l'API Firebase Cloud Messaging v1 avec authentification OAuth 2.0 via Service Account.
                            Remplace progressivement l'API Legacy qui sera désactivée par Google.
                        </div>
                        <div class="migration-tables">
                            <h4>Paramètres ajoutés :</h4>
                            <ul>
                                <li>✅ <code>firebase_use_v1_api</code> - Toggle pour activer l'API v1 (recommandé)</li>
                                <li>✅ <code>firebase_service_account_json</code> - Credentials Service Account pour OAuth 2.0</li>
                            </ul>
                        </div>
                        <div class="alert alert-success" style="margin-top: 15px; background: #d5f4e6; border-left: 4px solid #0e6655; padding: 10px;">
                            <i class="fa fa-check-circle"></i>
                            <strong>Recommandé :</strong> Cette migration est nécessaire pour profiter de l'API v1 moderne avec sécurité renforcée (OAuth 2.0),
                            meilleure gestion des erreurs et compatibilité future. L'API Legacy reste disponible pour la transition.
                        </div>
                        <div class="alert alert-info" style="margin-top: 10px; background: #e3f2fd; border-left: 4px solid #2196F3; padding: 10px;">
                            <i class="fa fa-info-circle"></i>
                            <strong>Après installation :</strong>
                            <ol style="margin: 10px 0 0 20px;">
                                <li>Allez dans <strong>Configuration → Firebase (Notifications Push)</strong></li>
                                <li>Sélectionnez <strong>"API v1 (Service Account)"</strong></li>
                                <li>Obtenez votre Service Account JSON depuis Firebase Console</li>
                                <li>Collez le contenu JSON dans le champ prévu</li>
                            </ol>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_firebase_v1_api_support.sql
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('firebase_v1')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('firebase_v1')" style="background: #4285F4;">
                                <i class="fa fa-rocket"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 6: Statistics Notes -->
                <div class="migration-card" data-migration="statistics_notes">
                    <div class="migration-card-header">
                        <h3>
                            <i class="fa fa-sticky-note"></i>
                            Notes sur Statistiques
                        </h3>
                        <span class="migration-status pending" id="status-statistics_notes">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            Ajout du système de notes personnelles pour les patients. Permet d'annoter les graphiques de statistiques avec des événements importants (exercice, vacances, changements alimentaires, etc.)
                        </div>
                        <div class="migration-tables">
                            <h4>Tables créées :</h4>
                            <ul>
                                <li><code>tbldietic_statistics_notes</code> - Notes des patients sur leurs graphiques</li>
                                <li>Support des icônes personnalisées (exercice, alimentation, vacances, santé, milestones)</li>
                                <li>Affichage contextuel par période sur les statistiques</li>
                            </ul>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_statistics_notes.php
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('statistics_notes')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('statistics_notes')">
                                <i class="fa fa-play"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 7: Hydration Tracking -->
                <div class="migration-card" data-migration="hydration_tracking">
                    <div class="migration-card-header">
                        <h3>
                            <i class="fa fa-tint"></i>
                            Suivi d'Hydratation
                        </h3>
                        <span class="migration-status pending" id="status-hydration_tracking">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            Système de suivi d'hydratation quotidienne pour les patients. Interface interactive avec animation d'eau, boutons rapides (250ml, 500ml, 750ml) et objectifs personnalisables.
                        </div>
                        <div class="migration-tables">
                            <h4>Tables créées :</h4>
                            <ul>
                                <li><code>tbldietic_hydration_tracking</code> - Enregistrement de la consommation d'eau</li>
                                <li><code>tbldietic_hydration_goals</code> - Objectifs d'hydratation personnalisés (défaut: 2000ml)</li>
                                <li>Historique journalier avec horodatage</li>
                                <li>Animation visuelle de progression</li>
                            </ul>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_hydration_tracking.php
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('hydration_tracking')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('hydration_tracking')">
                                <i class="fa fa-play"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 8: Activity Tracking -->
                <div class="migration-card" data-migration="activity_tracking">
                    <div class="migration-card-header">
                        <h3>
                            <i class="fa fa-heartbeat"></i>
                            Suivi d'Activités Sportives
                        </h3>
                        <span class="migration-status pending" id="status-activity_tracking">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            Système complet de suivi des activités sportives. Base de données avec <strong>86 activités</strong> pré-configurées (marche, course, vélo, natation, football, arts martiaux, danse, etc.), calcul automatique des calories selon la durée personnalisable par le patient.
                        </div>
                        <div class="migration-tables">
                            <h4>Tables créées :</h4>
                            <ul>
                                <li><code>tbldietic_activities</code> - Base de données des activités (nom, kcal/min, catégorie)</li>
                                <li><code>tbldietic_patient_activities</code> - Suivi des activités des patients</li>
                                <li><strong>86 activités</strong> par défaut avec valeurs kcal/minute précises</li>
                                <li>Calcul automatique des calories brûlées selon durée</li>
                                <li><strong>Catégories:</strong> Cardio (marche, course, vélo, natation), Musculation (pompes, squats, burpees), Sports collectifs (football, basketball, tennis), Arts martiaux (boxe, karaté, judo, MMA), Danse (zumba, salsa, hip-hop), Yoga/Étirements</li>
                            </ul>
                        </div>
                        <div class="alert alert-info" style="margin-top: 15px; background: #e3f2fd; border-left: 4px solid #2196F3; padding: 10px;">
                            <i class="fa fa-info-circle"></i>
                            <strong>Calcul par défaut :</strong> Chaque activité est calculée sur 30 minutes par défaut. Les patients peuvent personnaliser la durée et les calories sont recalculées automatiquement.
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_activity_tracking.php
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('activity_tracking')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('activity_tracking')">
                                <i class="fa fa-play"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Migration 9: Gamification System -->
                <div class="migration-card" data-migration="achievements_badges" style="border: 2px solid #FFD700;">
                    <div class="migration-card-header" style="background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);">
                        <h3>
                            <i class="fa fa-trophy"></i>
                            🎮 Système de Gamification - Badges & Points
                        </h3>
                        <span class="migration-status pending" id="status-achievements_badges">En attente</span>
                    </div>
                    <div class="migration-card-body">
                        <div class="migration-description">
                            <strong>Système complet de gamification :</strong> Badges, Points, Niveaux et Achievements pour motiver les patients.
                            Encourage l'engagement quotidien avec un système de récompenses visuelles et progressives.
                        </div>
                        <div class="migration-tables">
                            <h4>Tables créées :</h4>
                            <ul>
                                <li><code>tbldietic_badge_definitions</code> - 20 badges prédéfinis (streak, poids, nutrition, hydratation, activité)</li>
                                <li><code>tbldietic_patient_badges</code> - Badges débloqués par patient</li>
                                <li><code>tbldietic_patient_points</code> - Points et niveaux (Débutant → Diamant)</li>
                                <li><code>tbldietic_points_history</code> - Historique des points gagnés</li>
                            </ul>
                        </div>
                        <div class="alert alert-success" style="margin-top: 15px; background: #d5f4e6; border-left: 4px solid #0e6655; padding: 10px;">
                            <i class="fa fa-check-circle"></i>
                            <strong>Inclus :</strong>
                            <ul style="margin: 10px 0 0 20px;">
                                <li>🏆 20 badges répartis en 6 catégories</li>
                                <li>⭐ 6 niveaux progressifs (Débutant → Diamant)</li>
                                <li>💰 Système de points avec attribution automatique</li>
                                <li>🎨 Interface visuelle moderne (badge wall)</li>
                                <li>🔔 Notifications push au déblocage</li>
                                <li>📊 Stats temps réel (jour/semaine/mois)</li>
                            </ul>
                        </div>
                        <div class="alert alert-info" style="margin-top: 10px; background: #e3f2fd; border-left: 4px solid #2196F3; padding: 10px;">
                            <i class="fa fa-info-circle"></i>
                            <strong>Après installation :</strong>
                            <ol style="margin: 10px 0 0 20px;">
                                <li>Le widget "Mes Succès" sera disponible pour le dashboard patient</li>
                                <li>Les badges seront attribués automatiquement selon les actions</li>
                                <li>Consultez <code>GAMIFICATION_INTEGRATION_GUIDE.md</code> pour l'intégration</li>
                            </ol>
                        </div>
                    </div>
                    <div class="migration-card-footer">
                        <div class="migration-meta">
                            <i class="fa fa-file-code-o"></i> add_achievements_badges.sql
                        </div>
                        <div class="migration-actions">
                            <button class="btn-check" onclick="checkMigration('achievements_badges')">
                                <i class="fa fa-search"></i> Vérifier
                            </button>
                            <button class="btn-migrate" onclick="runMigration('achievements_badges')" style="background: #FFD700; color: #2c3e50;">
                                <i class="fa fa-trophy"></i> Installer
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Back Link -->
            <a href="<?php echo admin_url('dietetic/notifications/settings'); ?>" class="btn btn-default">
                <i class="fa fa-arrow-left"></i>
                Retour aux paramètres
            </a>
        </div>
    </div>
</div>

<?php init_tail(); ?>

<script>
// Migration configurations
const migrations = {
    lam_update: {
        name: 'Mise à jour LAM SMS',
        file: 'update_lam_sms_config.sql',
        settings: ['sms_lam_account_id', 'sms_lam_password', 'sms_lam_ret_url', 'sms_lam_priority']
    },
    notifications: {
        name: 'Système de Notifications',
        file: 'add_notifications_system.sql',
        tables: ['dietic_notification_preferences', 'dietic_notification_logs', 'dietic_milestones', 'dietic_notification_settings']
    },
    firebase: {
        name: 'Firebase Push',
        file: 'add_firebase_push_notifications.sql',
        tables: ['dietic_fcm_tokens']
    },
    optimizations: {
        name: 'Optimisations Performance',
        file: 'optimize_notifications_performance.sql',
        indexes: true
    },
    permissions: {
        name: 'Permissions Granulaires',
        file: 'add_staff_permissions.sql',
        tables: ['dietic_staff_permissions']
    },
    firebase_v1: {
        name: 'Firebase API v1',
        file: 'add_firebase_v1_api_support.sql',
        settings: ['firebase_use_v1_api', 'firebase_service_account_json']
    },
    statistics_notes: {
        name: 'Notes sur Statistiques',
        file: 'add_statistics_notes.php',
        tables: ['dietic_statistics_notes']
    },
    hydration_tracking: {
        name: 'Suivi d\'Hydratation',
        file: 'add_hydration_tracking.php',
        tables: ['dietic_hydration_tracking', 'dietic_hydration_goals']
    },
    activity_tracking: {
        name: 'Suivi d\'Activités Sportives',
        file: 'add_activity_tracking.php',
        tables: ['dietic_activities', 'dietic_patient_activities']
    },
    achievements_badges: {
        name: 'Système de Gamification',
        file: 'add_achievements_badges.sql',
        tables: ['dietic_badge_definitions', 'dietic_patient_badges', 'dietic_patient_points', 'dietic_points_history']
    }
};

// Check single migration
function checkMigration(migrationId) {
    const btn = event.target;
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Vérification...';

    // Get CSRF token
    var csrfData = {};
    csrfData[csrf_token_name] = csrf_hash_name;

    $.ajax({
        url: admin_url + 'dietetic/notifications/check_migration',
        type: 'POST',
        data: $.extend({ migration: migrationId }, csrfData),
        dataType: 'json',
        success: function(response) {
            updateMigrationStatus(migrationId, response.installed, response.message);
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        },
        error: function() {
            alert_float('danger', 'Erreur lors de la vérification');
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }
    });
}

// Check all migrations
function checkAllMigrations() {
    const btn = document.getElementById('checkAllBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Vérification...';

    let checked = 0;
    const total = Object.keys(migrations).length;

    // Get CSRF token
    var csrfData = {};
    csrfData[csrf_token_name] = csrf_hash_name;

    Object.keys(migrations).forEach(migrationId => {
        $.ajax({
            url: admin_url + 'dietetic/notifications/check_migration',
            type: 'POST',
            data: $.extend({ migration: migrationId }, csrfData),
            dataType: 'json',
            success: function(response) {
                updateMigrationStatus(migrationId, response.installed, response.message);
                checked++;

                if (checked === total) {
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fa fa-search"></i> Vérifier tout';
                    showAlert('info', 'Vérification terminée pour ' + total + ' migration(s)');
                }
            }
        });
    });
}

// Run single migration
function runMigration(migrationId) {
    const btn = event.target;
    const originalHtml = btn.innerHTML;

    if (!confirm('Voulez-vous vraiment exécuter cette migration ?')) {
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Installation...';

    // Get CSRF token
    var csrfData = {};
    csrfData[csrf_token_name] = csrf_hash_name;

    $.ajax({
        url: admin_url + 'dietetic/notifications/execute_migration',
        type: 'POST',
        data: $.extend({ migration: migrationId }, csrfData),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                updateMigrationStatus(migrationId, true, response.message);
                showAlert('success', response.message);
                btn.innerHTML = '<i class="fa fa-check"></i> Installé';
            } else {
                showAlert('error', response.message);
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }
        },
        error: function(xhr) {
            const message = xhr.responseJSON?.message || 'Erreur lors de l\'installation';
            showAlert('error', message);
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }
    });
}

// Run all migrations
function runAllMigrations() {
    const btn = document.getElementById('runAllBtn');

    if (!confirm('Voulez-vous installer toutes les migrations manquantes ?')) {
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Installation...';

    const progressBar = document.getElementById('progressBar');
    const progressBarFill = document.getElementById('progressBarFill');
    progressBar.style.display = 'block';

    const migrationIds = Object.keys(migrations);
    let completed = 0;
    let errors = 0;

    // Get CSRF token
    var csrfData = {};
    csrfData[csrf_token_name] = csrf_hash_name;

    function runNext(index) {
        if (index >= migrationIds.length) {
            // All done
            progressBar.style.display = 'none';
            btn.disabled = false;
            btn.innerHTML = '<i class="fa fa-rocket"></i> Tout installer';

            if (errors === 0) {
                showAlert('success', 'Toutes les migrations ont été installées avec succès !');
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } else {
                showAlert('error', errors + ' migration(s) ont échoué');
            }
            return;
        }

        const migrationId = migrationIds[index];
        const progress = ((index + 1) / migrationIds.length) * 100;
        progressBarFill.style.width = progress + '%';

        $.ajax({
            url: admin_url + 'dietetic/notifications/execute_migration',
            type: 'POST',
            data: $.extend({ migration: migrationId }, csrfData),
            dataType: 'json',
            success: function(response) {
                if (response.success || response.already_exists) {
                    updateMigrationStatus(migrationId, true, response.message);
                } else {
                    errors++;
                    updateMigrationStatus(migrationId, false, 'Erreur');
                }
                runNext(index + 1);
            },
            error: function() {
                errors++;
                updateMigrationStatus(migrationId, false, 'Erreur');
                runNext(index + 1);
            }
        });
    }

    runNext(0);
}

// Update migration status
function updateMigrationStatus(migrationId, installed, message) {
    const statusEl = document.getElementById('status-' + migrationId);
    if (!statusEl) return;

    statusEl.className = 'migration-status ' + (installed ? 'completed' : 'pending');
    statusEl.textContent = installed ? 'Installé' : 'En attente';
}

// Show alert
function showAlert(type, message) {
    const alertBox = document.getElementById('alertBox');
    alertBox.className = 'alert-box ' + type;
    alertBox.innerHTML = '<i class="fa fa-' + (type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle') + '"></i> ' + message;
    alertBox.style.display = 'block';

    setTimeout(() => {
        alertBox.style.display = 'none';
    }, 5000);
}

// Check all migrations on load
$(document).ready(function() {
    checkAllMigrations();
});
</script>

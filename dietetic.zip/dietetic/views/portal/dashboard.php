<?php
$active_page = 'dashboard';
$page_title = 'Mon Programme';
$this->load->view('portal/includes/portal_header');
?>

<style>
/* Weight Goal Card - Unified Block */
.weight-goal-card {
    background: white;
    border-radius: 16px;
    padding: 28px 32px;
    border: 2px solid #f1f3f5;
    margin-bottom: 24px;
    transition: all 0.3s;
}

.weight-goal-card:hover {
    border-color: #01807B;
    box-shadow: 0 8px 20px rgba(1, 128, 123, 0.12);
}

.weight-goal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 24px;
    padding-bottom: 16px;
    border-bottom: 2px solid #f1f3f5;
}

.weight-goal-title {
    font-size: 20px;
    font-weight: 700;
    color: #212529;
    display: flex;
    align-items: center;
    gap: 10px;
}

.weight-goal-title i {
    color: #01807B;
}

.weight-goal-status {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
}

.weight-goal-status.achieved {
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
}

.weight-goal-status.on-track {
    background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
    color: white;
}

.weight-goal-status.ahead {
    background: linear-gradient(135deg, #9f7aea 0%, #805ad5 100%);
    color: white;
}

.weight-goal-status.behind {
    background: linear-gradient(135deg, #F3911D 0%, #dd7711 100%);
    color: white;
}

.weight-goal-status.no-data {
    background: #e9ecef;
    color: #6c757d;
}

.weight-values {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    gap: 24px;
    align-items: center;
    margin-bottom: 24px;
}

.weight-value-item {
    text-align: center;
}

.weight-value-label {
    font-size: 12px;
    color: #6c757d;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
}

.weight-value-number {
    font-size: 36px;
    font-weight: 700;
    color: #212529;
    line-height: 1;
}

.weight-value-unit {
    font-size: 16px;
    color: #6c757d;
    font-weight: 500;
    margin-left: 4px;
}

.weight-arrow {
    font-size: 32px;
    color: #01807B;
}

.weight-remaining {
    padding: 16px 20px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 12px;
    border-left: 4px solid #01807B;
    text-align: center;
    margin-bottom: 20px;
}

.weight-remaining-text {
    font-size: 14px;
    color: #495057;
    font-weight: 600;
    margin-bottom: 4px;
}

.weight-remaining-value {
    font-size: 24px;
    font-weight: 700;
    color: #01807B;
}

.progress-gauge-container {
    margin-bottom: 20px;
}

.progress-gauge-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.progress-gauge-label {
    font-size: 13px;
    color: #6c757d;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.progress-gauge-percent {
    font-size: 20px;
    font-weight: 700;
    color: #01807B;
}

/* Cercle de progression visuel */
.progress-visual-container {
    position: relative;
    width: 200px;
    height: 200px;
    margin: 20px auto;
}

.progress-circle-svg {
    width: 100%;
    height: 100%;
    transform: rotate(-90deg);
}

.progress-circle-bg {
    fill: none;
    stroke: #e9ecef;
    stroke-width: 12;
}

.progress-circle-fill {
    fill: none;
    stroke: url(#progressGradient);
    stroke-width: 12;
    stroke-linecap: round;
    stroke-dasharray: 534.07;
    transition: stroke-dashoffset 1.5s cubic-bezier(0.68, -0.55, 0.27, 1.55);
    filter: drop-shadow(0 0 8px rgba(1, 128, 123, 0.3));
}

.progress-circle-text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
}

.progress-circle-number {
    font-size: 48px;
    font-weight: 800;
    color: #01807B;
    line-height: 1;
    font-family: 'Montserrat', 'Avenir Next', sans-serif;
    letter-spacing: -2px;
}

.progress-percent-symbol {
    font-size: 28px;
    font-weight: 700;
    margin-left: 2px;
}

.progress-circle-label {
    font-size: 12px;
    font-weight: 700;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-top: 8px;
}

.progress-gauge-bar {
    position: relative;
    height: 20px;
    background: #e9ecef;
    border-radius: 10px;
    overflow: hidden;
}

.progress-gauge-fill {
    height: 100%;
    background: linear-gradient(90deg, #01807B 0%, #019B95 100%);
    border-radius: 10px;
    transition: width 1s ease-out;
    position: relative;
}

.progress-gauge-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.3) 50%, transparent 100%);
    animation: shimmer 2s infinite;
}

@keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

.weight-motivation-message {
    padding: 16px 20px;
    border-radius: 12px;
    font-size: 15px;
    line-height: 1.6;
    font-weight: 500;
    text-align: center;
}

.weight-motivation-message.achieved {
    background: linear-gradient(135deg, #e6ffed 0%, #d4fce3 100%);
    border: 2px solid #48bb78;
    color: #1e6b39;
}

.weight-motivation-message.on-track {
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
    border: 2px solid #4299e1;
    color: #1e40af;
}

.weight-motivation-message.ahead {
    background: linear-gradient(135deg, #f3e8ff 0%, #e9d5ff 100%);
    border: 2px solid #9f7aea;
    color: #5b21b6;
}

.weight-motivation-message.behind {
    background: linear-gradient(135deg, #fff4e6 0%, #ffe8cc 100%);
    border: 2px solid #F3911D;
    color: #92400e;
}

.weight-motivation-message.no-data {
    background: #f8f9fa;
    border: 2px solid #dee2e6;
    color: #6c757d;
}

.weight-motivation-message strong {
    font-weight: 700;
}

/* Hydration Section - Compact Version */
.hydration-card-compact {
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    border: 2px solid #e3f2fd;
    margin-bottom: 24px;
    transition: all 0.3s;
}

.hydration-card-compact:hover {
    border-color: #4fc3f7;
    box-shadow: 0 4px 12px rgba(79, 195, 247, 0.15);
}

.hydration-header-compact {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12px;
}

.hydration-title-compact {
    font-size: 16px;
    font-weight: 700;
    color: #01579b;
    display: flex;
    align-items: center;
    gap: 8px;
}

.hydration-title-compact i {
    color: #0288d1;
    font-size: 18px;
}

.hydration-goal-display {
    font-size: 18px;
    font-weight: 700;
    color: #0288d1;
}

.hydration-goal-display span {
    color: #01579b;
}

.hydration-progress-bar {
    height: 12px;
    background: #e3f2fd;
    border-radius: 6px;
    overflow: hidden;
    margin-bottom: 16px;
    position: relative;
}

.hydration-progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #4fc3f7 0%, #0288d1 100%);
    border-radius: 6px;
    transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
}

.hydration-progress-fill::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.3) 50%, transparent 100%);
    animation: shimmer 2s infinite;
}

@keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

.hydration-actions-compact {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.hydration-row {
    display: grid;
    grid-template-columns: 200px 1fr;
    gap: 16px;
    align-items: flex-end;
}

.custom-input-section {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.compact-label {
    font-size: 10px;
    font-weight: 600;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin: 0;
}

.compact-input {
    width: 100%;
    padding: 10px 14px;
    border: 2px solid #90caf9;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    color: #01579b;
    transition: all 0.3s;
}

.compact-input:focus {
    outline: none;
    border-color: #0288d1;
    box-shadow: 0 0 0 3px rgba(2, 136, 209, 0.1);
}

.quick-buttons-inline {
    display: flex;
    gap: 12px;
    align-items: flex-end;
    justify-content: flex-start;
}

/* Water Glass Buttons */
.quick-btn-glass {
    background: transparent;
    border: none;
    cursor: pointer;
    padding: 0;
    transition: transform 0.3s;
}

.quick-btn-glass:hover {
    transform: translateY(-5px);
}

.quick-btn-glass:active {
    transform: translateY(-2px);
}

.water-glass-small,
.water-glass-medium,
.water-glass-large {
    position: relative;
    background: linear-gradient(180deg,
        rgba(79, 195, 247, 0.1) 0%,
        rgba(79, 195, 247, 0.2) 100%);
    border: 3px solid rgba(79, 195, 247, 0.6);
    border-top: none;
    border-radius: 0 0 20px 20px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}

.water-glass-small {
    width: 60px;
    height: 80px;
}

.water-glass-medium {
    width: 70px;
    height: 95px;
}

.water-glass-large {
    width: 80px;
    height: 110px;
}

.water-fill {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 65%;
    background: linear-gradient(180deg, #4fc3f7 0%, #0288d1 100%);
    border-radius: 0 0 inherit inherit;
}

.water-wave {
    position: absolute;
    top: -10px;
    left: -50%;
    width: 200%;
    height: 15px;
    background: rgba(255, 255, 255, 0.4);
    border-radius: 45%;
    animation: wave 3s linear infinite;
}

@keyframes wave {
    0%, 100% {
        transform: translateX(0) translateY(0);
    }
    25% {
        transform: translateX(-15%) translateY(-3px);
    }
    50% {
        transform: translateX(-30%) translateY(0);
    }
    75% {
        transform: translateX(-15%) translateY(-3px);
    }
}

.water-cup-add {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 32px;
    height: 32px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    z-index: 3;
}

.water-cup-add i {
    font-size: 16px;
    color: #0288d1;
}

.water-amount {
    position: absolute;
    bottom: 6px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 12px;
    font-weight: 700;
    color: white;
    z-index: 2;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}

.add-custom-btn-compact {
    padding: 10px 16px;
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 700;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 6px rgba(72, 187, 120, 0.3);
    min-width: 44px;
}

.add-custom-btn-compact:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(72, 187, 120, 0.4);
}

.add-custom-btn-compact:active {
    transform: translateY(0);
}

/* Hydration History - Compact */
.hydration-history-compact {
    margin-top: 20px;
    padding-top: 16px;
    border-top: 1px solid #e3f2fd;
}

.history-title-compact {
    font-size: 11px;
    font-weight: 600;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
}

.history-bars-compact {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 8px;
}

.history-bar-compact {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
}

.history-bar-fill-compact {
    width: 100%;
    height: 60px;
    background: #e3f2fd;
    border-radius: 6px;
    position: relative;
    overflow: hidden;
}

.history-bar-value-compact {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    background: linear-gradient(180deg, #4fc3f7 0%, #0288d1 100%);
    border-radius: 6px;
    transition: height 0.5s ease;
}

.history-day-compact {
    font-size: 10px;
    font-weight: 600;
    color: #01579b;
}

/* Other Stats Cards */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    border-radius: 12px;
    padding: 24px;
    text-align: center;
    border: 2px solid #f1f3f5;
    transition: all 0.3s;
}

.stat-card:hover {
    border-color: #01807B;
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(1, 128, 123, 0.15);
}

.stat-card .stat-icon {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    margin: 0 auto 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.stat-card.bmi .stat-icon {
    background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
    color: white;
}

.stat-card.progress .stat-icon {
    background: linear-gradient(135deg, #9f7aea 0%, #805ad5 100%);
    color: white;
}

.stat-card .stat-value {
    font-size: 32px;
    font-weight: 700;
    color: #212529;
    margin: 0 0 8px 0;
    line-height: 1;
}

.stat-card .stat-label {
    font-size: 14px;
    color: #6c757d;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-value.text-success {
    color: #48bb78 !important;
}

/* Program Card - Flat Design */
.program-card {
    background: white;
    border-radius: 16px;
    overflow: hidden;
    border: 2px solid #f1f3f5;
    margin-bottom: 30px;
}

.program-header {
    background: linear-gradient(135deg, #01807B 0%, #019B95 100%);
    padding: 32px 28px;
    color: white;
    position: relative;
}

.program-header::before {
    content: '';
    position: absolute;
    top: -50px;
    right: -50px;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.program-title {
    font-size: 24px;
    font-weight: 700;
    margin: 0 0 8px 0;
    position: relative;
    z-index: 1;
}

.program-status {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255, 255, 255, 0.25);
    padding: 6px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    position: relative;
    z-index: 1;
}

.program-status i {
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.program-body {
    padding: 28px;
}

.program-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 24px;
}

.info-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 16px;
    background: #f8f9fa;
    border-radius: 10px;
    border-left: 4px solid #01807B;
}

.info-item i {
    font-size: 20px;
    color: #01807B;
    margin-top: 2px;
}

.info-content {
    flex: 1;
}

.info-label {
    font-size: 12px;
    color: #6c757d;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 4px;
}

.info-value {
    font-size: 16px;
    color: #212529;
    font-weight: 600;
}

.program-objective {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 20px;
    border-radius: 12px;
    border-left: 4px solid #F3911D;
    margin: 20px 0;
}

.program-objective strong {
    display: block;
    color: #01807B;
    font-size: 14px;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.program-objective p {
    color: #495057;
    line-height: 1.8;
    margin: 0;
}

/* Meal Plans Section */
.meal-plans-section {
    margin-top: 24px;
    padding-top: 24px;
    border-top: 2px solid #f1f3f5;
}

.section-title {
    font-size: 18px;
    font-weight: 700;
    color: #212529;
    margin: 0 0 20px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-title i {
    color: #01807B;
}

.meal-plan-item {
    background: white;
    border: 2px solid #e9ecef;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 12px;
    transition: all 0.3s;
}

.meal-plan-item:hover {
    border-color: #01807B;
    transform: translateX(4px);
    box-shadow: 0 4px 12px rgba(1, 128, 123, 0.1);
}

.meal-plan-name {
    font-size: 16px;
    font-weight: 600;
    color: #212529;
    margin-bottom: 12px;
}

.meal-plan-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.btn-flat {
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 14px;
    border: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
    text-decoration: none;
}

.btn-flat-primary {
    background: #01807B;
    color: white;
}

.btn-flat-primary:hover {
    background: #026660;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(1, 128, 123, 0.3);
    color: white;
    text-decoration: none;
}

.btn-flat-success {
    background: #48bb78;
    color: white;
}

.btn-flat-success:hover {
    background: #38a169;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(72, 187, 120, 0.3);
    color: white;
    text-decoration: none;
}

/* Consultations Card - Timeline Design */
.consultations-card {
    background: white;
    border-radius: 16px;
    border: 2px solid #f1f3f5;
    overflow: hidden;
}

.consultations-header {
    background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
    padding: 20px 24px;
    color: white;
}

.consultations-header h4 {
    margin: 0;
    font-size: 18px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 10px;
}

.consultations-body {
    padding: 24px;
}

.consultation-timeline {
    position: relative;
}

.consultation-timeline::before {
    content: '';
    position: absolute;
    left: 20px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: linear-gradient(180deg, #4299e1 0%, #e9ecef 100%);
}

.consultation-item {
    position: relative;
    padding-left: 56px;
    margin-bottom: 24px;
}

.consultation-item:last-child {
    margin-bottom: 0;
}

.consultation-dot {
    position: absolute;
    left: 12px;
    top: 4px;
    width: 18px;
    height: 18px;
    background: #4299e1;
    border: 3px solid white;
    border-radius: 50%;
    box-shadow: 0 0 0 2px #4299e1;
    z-index: 1;
}

.consultation-content {
    background: #f8f9fa;
    padding: 16px;
    border-radius: 10px;
    border-left: 3px solid #4299e1;
}

.consultation-date {
    font-size: 14px;
    font-weight: 700;
    color: #01807B;
    margin-bottom: 6px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.consultation-type {
    font-size: 13px;
    color: #495057;
    margin-bottom: 8px;
}

.consultation-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: #4299e1;
    color: white;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.consultation-badge-pending {
    background: #f59e0b;
    color: white;
}

.consultation-badge-scheduled {
    background: #10b981;
    color: white;
}

.consultation-badge-rejected {
    background: #dc2626;
    color: white;
}

.consultation-badge-cancelled {
    background: #ef4444;
    color: white;
}

.empty-consultations {
    text-align: center;
    padding: 32px 20px;
    color: #6c757d;
}

.empty-consultations i {
    font-size: 48px;
    opacity: 0.3;
    margin-bottom: 12px;
}

.chart-card {
    background: white;
    border-radius: 16px;
    padding: 24px;
    border: 2px solid #f1f3f5;
}

.chart-card h4 {
    font-size: 18px;
    font-weight: 700;
    color: #212529;
    margin: 0 0 20px 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.chart-card h4 i {
    color: #01807B;
}

.no-program-alert {
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
    border: 2px solid #4299e1;
    border-radius: 16px;
    padding: 32px;
    text-align: center;
    margin-bottom: 30px;
}

.no-program-alert i {
    font-size: 56px;
    color: #4299e1;
    margin-bottom: 16px;
}

.no-program-alert p {
    font-size: 16px;
    color: #1e40af;
    font-weight: 500;
    margin: 0;
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .program-info-grid {
        grid-template-columns: 1fr;
    }

    .meal-plan-actions {
        flex-direction: column;
    }

    .btn-flat {
        width: 100%;
        justify-content: center;
    }

    /* Hydration compact responsive */
    .hydration-row {
        grid-template-columns: 1fr;
        gap: 12px;
    }

    .quick-buttons-inline {
        flex-wrap: wrap;
        justify-content: center;
        gap: 10px;
    }

    .water-glass-small {
        width: 55px;
        height: 70px;
    }

    .water-glass-medium {
        width: 65px;
        height: 85px;
    }

    .water-glass-large {
        width: 75px;
        height: 100px;
    }

    .water-cup-add {
        width: 28px;
        height: 28px;
    }

    .water-cup-add i {
        font-size: 14px;
    }

    .water-amount {
        font-size: 11px;
    }

    .add-custom-btn-compact {
        width: 100%;
        margin-top: 10px;
    }

    .hydration-goal-display {
        font-size: 12px;
    }

    .hydration-title-compact {
        font-size: 14px;
    }

    .history-bars-compact {
        gap: 4px;
    }

    .history-bar-fill-compact {
        height: 50px;
    }
}

/* ============================================
   BLOG CAROUSEL - Conseils
   ============================================ */
.blog-carousel-section {
    background: white;
    border-radius: 16px;
    padding: 24px 28px;
    border: 2px solid #f1f3f5;
    margin-top: 24px;
    margin-bottom: 24px;
    transition: all 0.3s;
}

.blog-carousel-section:hover {
    border-color: #01807B;
    box-shadow: 0 8px 20px rgba(1, 128, 123, 0.12);
}

.blog-carousel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}

.blog-carousel-title {
    font-size: 18px;
    font-weight: 700;
    color: #212529;
    display: flex;
    align-items: center;
    gap: 10px;
}

.blog-carousel-title i {
    color: #01807B;
    font-size: 20px;
}

.blog-view-all {
    padding: 8px 16px;
    background: #01807B;
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    font-size: 13px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s;
}

.blog-view-all:hover {
    background: #026660;
    text-decoration: none;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(1, 128, 123, 0.3);
}

.blog-carousel-container {
    position: relative;
    overflow: hidden;
}

.blog-carousel-track {
    display: flex;
    gap: 16px;
    transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    padding-bottom: 10px;
}

.blog-card-carousel {
    flex: 0 0 calc(33.333% - 12px);
    background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
    border-radius: 12px;
    padding: 20px;
    border: 2px solid #e9ecef;
    transition: all 0.3s;
    cursor: pointer;
    text-decoration: none;
    color: inherit;
    min-height: 140px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.blog-card-carousel:hover {
    border-color: #01807B;
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(1, 128, 123, 0.15);
    text-decoration: none;
}

.blog-card-category {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 4px 10px;
    background: rgba(1, 128, 123, 0.1);
    color: #01807B;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
    align-self: flex-start;
}

.blog-card-title-carousel {
    font-size: 16px;
    font-weight: 700;
    color: #212529;
    line-height: 1.4;
    margin-bottom: 12px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    flex: 1;
}

.blog-card-footer-carousel {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 12px;
    border-top: 1px solid #e9ecef;
    font-size: 11px;
    color: #6c757d;
}

.blog-carousel-nav {
    display: flex;
    gap: 10px;
    justify-content: center;
    margin-top: 20px;
}

.blog-nav-btn {
    width: 44px;
    height: 44px;
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s;
    color: #6c757d;
    font-size: 18px;
}

.blog-nav-btn:hover:not(:disabled) {
    background: #01807B;
    border-color: #01807B;
    color: white;
    transform: scale(1.1);
}

.blog-nav-btn:disabled {
    opacity: 0.3;
    cursor: not-allowed;
}

.blog-carousel-dots {
    display: flex;
    gap: 8px;
    justify-content: center;
    margin-top: 16px;
}

.blog-carousel-dot {
    width: 8px;
    height: 8px;
    background: #e9ecef;
    border-radius: 50%;
    cursor: pointer;
    transition: all 0.3s;
}

.blog-carousel-dot.active {
    width: 24px;
    border-radius: 4px;
    background: #01807B;
}

.blog-empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #6c757d;
}

.blog-empty-state i {
    font-size: 48px;
    opacity: 0.3;
    margin-bottom: 12px;
    display: block;
}

@media (max-width: 992px) {
    .blog-card-carousel {
        flex: 0 0 calc(50% - 8px);
    }
}

@media (max-width: 576px) {
    .blog-card-carousel {
        flex: 0 0 100%;
    }

    .blog-carousel-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }

    .blog-view-all {
        width: 100%;
        justify-content: center;
    }
}

/* ============================================
   ACTIVITIES CARD - Compact & Fun
   ============================================ */
.activities-card-compact {
    background: white;
    border-radius: 16px;
    padding: 24px 28px;
    border: 2px solid #f1f3f5;
    margin-bottom: 24px;
    transition: all 0.3s;
}

.activities-card-compact:hover {
    border-color: #F3911D;
    box-shadow: 0 8px 20px rgba(243, 145, 29, 0.12);
}

.activities-header-compact {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
}

.activities-title-compact {
    font-size: 18px;
    font-weight: 700;
    color: #212529;
    display: flex;
    align-items: center;
    gap: 10px;
}

.activities-title-compact i {
    color: #F3911D;
    font-size: 20px;
}

.activities-stats-row {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-bottom: 16px;
}

.activity-stat-item {
    background: linear-gradient(135deg, #fff5e6 0%, #ffe8cc 100%);
    border-radius: 12px;
    padding: 12px;
    text-align: center;
    border-left: 3px solid #F3911D;
    transition: all 0.2s;
}

.activity-stat-item:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(243, 145, 29, 0.15);
}

.activity-stat-value {
    font-size: 24px;
    font-weight: 700;
    color: #F3911D;
    line-height: 1;
    margin-bottom: 4px;
}

.activity-stat-label {
    font-size: 11px;
    color: #6c757d;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.activities-list-compact {
    margin-bottom: 16px;
}

.activity-item-compact {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 12px 14px;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-left: 3px solid #F3911D;
    transition: all 0.2s;
}

.activity-item-compact:hover {
    background: #fff5e6;
    transform: translateX(4px);
}

.activity-item-left {
    display: flex;
    align-items: center;
    gap: 12px;
    flex: 1;
}

.activity-icon-compact {
    width: 36px;
    height: 36px;
    background: linear-gradient(135deg, #F3911D 0%, #e67e00 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 16px;
}

.activity-info-compact {
    flex: 1;
}

.activity-name-compact {
    font-size: 14px;
    font-weight: 600;
    color: #212529;
    margin-bottom: 2px;
}

.activity-duration-compact {
    font-size: 12px;
    color: #6c757d;
    display: flex;
    align-items: center;
    gap: 4px;
}

.activity-kcal-compact {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 4px;
}

.no-activities-compact {
    text-align: center;
    padding: 24px 16px;
    color: #6c757d;
    font-size: 14px;
}

.no-activities-compact i {
    font-size: 40px;
    opacity: 0.3;
    margin-bottom: 8px;
    display: block;
}

.activities-actions-compact {
    display: flex;
    gap: 10px;
}

.btn-add-activity-compact {
    flex: 1;
    padding: 12px 20px;
    background: linear-gradient(135deg, #F3911D 0%, #e67e00 100%);
    color: white;
    border: none;
    border-radius: 10px;
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    box-shadow: 0 3px 8px rgba(243, 145, 29, 0.3);
}

.btn-add-activity-compact:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(243, 145, 29, 0.4);
}

.btn-add-activity-compact:active {
    transform: translateY(0);
}

.btn-view-all-activities {
    padding: 12px 20px;
    background: white;
    color: #F3911D;
    border: 2px solid #F3911D;
    border-radius: 10px;
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
}

.btn-view-all-activities:hover {
    background: #F3911D;
    color: white;
    transform: translateY(-2px);
}

@media (max-width: 768px) {
    .activities-stats-row {
        grid-template-columns: 1fr;
    }

    .activities-actions-compact {
        flex-direction: column;
    }
}
</style>

<?php
// === Weight Goal Progress Calculation ===
$current_weight = $patient->latest_measurement ? $patient->latest_measurement->weight : null;
$target_weight = $patient->target_weight;
$initial_weight = $weight_progress->initial_weight;

// Calculate remaining weight and determine goal type
$weight_remaining = null;
$goal_type = 'lose'; // 'lose', 'gain', or 'maintain'
if ($current_weight && $target_weight) {
    $weight_remaining = abs($current_weight - $target_weight);

    // Determine if client needs to lose or gain weight
    if ($current_weight > $target_weight) {
        $goal_type = 'lose';
    } elseif ($current_weight < $target_weight) {
        $goal_type = 'gain';
    } else {
        $goal_type = 'maintain';
    }
}

// Calculate progress percentage
// % = (Initial - Current) / (Initial - Target) * 100
$progress_percent = 0;
if ($initial_weight && $current_weight && $target_weight && $initial_weight != $target_weight) {
    $weight_lost = $initial_weight - $current_weight;
    $total_to_lose = $initial_weight - $target_weight;
    $progress_percent = ($weight_lost / $total_to_lose) * 100;
    $progress_percent = max(0, min(100, $progress_percent)); // Clamp between 0-100
}

// Calculate timeline status if program has dates
$timeline_status = 'no-data';
$timeline_message = '';
$weeks_elapsed = 0;
$weeks_total = 0;
$expected_loss = 0;
$actual_loss = 0;

if ($active_program && $active_program->start_date && $active_program->end_date) {
    $start = new DateTime($active_program->start_date);
    $end = new DateTime($active_program->end_date);
    $now = new DateTime();

    $total_days = $start->diff($end)->days;
    $elapsed_days = $start->diff($now)->days;

    $weeks_total = ceil($total_days / 7);
    $weeks_elapsed = ceil($elapsed_days / 7);

    if ($weeks_total > 0 && $initial_weight && $target_weight) {
        // Expected weekly loss rate
        $total_to_lose = $initial_weight - $target_weight;
        $weekly_loss_rate = $total_to_lose / $weeks_total;

        // Expected loss by now
        $expected_loss = $weekly_loss_rate * $weeks_elapsed;

        // Actual loss
        $actual_loss = $initial_weight - $current_weight;

        // Determine status
        $difference = $actual_loss - $expected_loss;

        if ($difference >= 0.5) {
            $timeline_status = 'ahead';
        } elseif ($difference <= -0.5) {
            $timeline_status = 'behind';
        } else {
            $timeline_status = 'on-track';
        }
    }
}

// Determine overall status
$overall_status = 'no-data';
$status_icon = 'fa-circle';

if (!$current_weight || !$target_weight) {
    $overall_status = 'no-data';
    $status_icon = 'fa-exclamation-circle';
} elseif ($progress_percent >= 100) {
    $overall_status = 'achieved';
    $status_icon = 'fa-trophy';
} elseif ($progress_percent >= 80 || $weight_remaining <= 2) {
    $overall_status = 'achieved'; // Close enough
    $status_icon = 'fa-check-circle';
} else {
    $overall_status = $timeline_status;
    if ($timeline_status == 'ahead') {
        $status_icon = 'fa-rocket';
    } elseif ($timeline_status == 'on-track') {
        $status_icon = 'fa-check';
    } elseif ($timeline_status == 'behind') {
        $status_icon = 'fa-clock';
    } else {
        $status_icon = 'fa-circle';
    }
}

// Generate motivation message
$motivation_message = '';
if (!$current_weight || !$target_weight) {
    $motivation_message = 'Entrez votre poids de la semaine pour mettre à jour votre progression.';
} else {
    // Calculate difference WITH direction for better messaging
    $weight_diff = $current_weight - $target_weight;
    $total_change = $initial_weight ? abs($current_weight - $initial_weight) : 0;

    if ($goal_type == 'lose') {
        if ($weight_diff > 0.5) {
            // Pas encore atteint
            if ($weight_remaining <= 2) {
                $motivation_message = '<strong>Presque au but</strong> — plus que ' . number_format($weight_diff, 1) . ' kg à perdre.';
            } elseif ($timeline_status == 'ahead') {
                $ahead_percent = abs(round(($actual_loss - $expected_loss) / $expected_loss * 100));
                $motivation_message = '<strong>Excellent !</strong> Vous devancez le planning de ' . $ahead_percent . ' %.';
            } elseif ($timeline_status == 'on-track') {
                $end_date = $active_program && $active_program->end_date ? date('d/m', strtotime($active_program->end_date)) : '';
                $motivation_message = '<strong>Solide !</strong> Vous êtes dans les temps' . ($end_date ? ' pour le ' . $end_date : '') . '.';
            } elseif ($timeline_status == 'behind') {
                $behind_kg = abs(round($actual_loss - $expected_loss, 1));
                $motivation_message = '<strong>Courage</strong> — encore ' . $behind_kg . ' kg à rattraper pour revenir dans les temps.';
            } else {
                $motivation_message = '<strong>Continue comme ça !</strong> Vous progressez vers votre objectif.';
            }
        } elseif (abs($weight_diff) <= 0.5) {
            // Objectif atteint
            $motivation_message = '🎉 <strong>Félicitations !</strong> Objectif atteint avec ' . number_format($total_change, 1) . ' kg perdus !';
        } else {
            // Objectif dépassé
            $excess = abs($weight_diff);
            $motivation_message = '🎉 <strong>Incroyable !</strong> Objectif dépassé ! Vous avez perdu ' . number_format($total_change, 1) . ' kg, soit ' . number_format($excess, 1) . ' kg de plus que l\'objectif.';
        }
    } elseif ($goal_type == 'gain') {
        $weight_diff_gain = $target_weight - $current_weight;
        if ($weight_diff_gain > 0.5) {
            // Pas encore atteint
            if ($weight_diff_gain <= 2) {
                $motivation_message = '<strong>Presque au but</strong> — plus que ' . number_format($weight_diff_gain, 1) . ' kg à gagner.';
            } else {
                $motivation_message = '<strong>Continue comme ça !</strong> Vous progressez vers votre objectif.';
            }
        } elseif (abs($weight_diff_gain) <= 0.5) {
            // Objectif atteint
            $motivation_message = '🎉 <strong>Félicitations !</strong> Objectif atteint avec ' . number_format($total_change, 1) . ' kg gagnés !';
        } else {
            // Objectif dépassé
            $excess = abs($weight_diff_gain);
            $motivation_message = '🎉 <strong>Incroyable !</strong> Objectif dépassé ! Vous avez gagné ' . number_format($total_change, 1) . ' kg, soit ' . number_format($excess, 1) . ' kg de plus que l\'objectif.';
        }
    } else {
        $motivation_message = '🎉 <strong>Parfait !</strong> Poids maintenu.';
    }
}
?>

<!-- Weight Goal Card -->
<div class="weight-goal-card">
    <div class="weight-goal-header">
        <div class="weight-goal-title">
            <i class="fa fa-bullseye"></i>
            Objectif de poids
        </div>
        <div class="weight-goal-status <?php echo $overall_status; ?>">
            <i class="fa <?php echo $status_icon; ?>"></i>
            <?php
            // Déterminer si objectif est atteint ou dépassé
            $weight_diff_status = $current_weight - $target_weight;
            $is_exceeded = false;

            if ($goal_type == 'lose' && $weight_diff_status < -0.5) {
                $is_exceeded = true;
            } elseif ($goal_type == 'gain' && $weight_diff_status > 0.5) {
                $is_exceeded = true;
            }

            if ($is_exceeded) {
                echo 'Objectif dépassé';
            } elseif ($overall_status == 'achieved') {
                echo 'Objectif atteint';
            } elseif ($overall_status == 'ahead') {
                echo 'En avance';
            } elseif ($overall_status == 'on-track') {
                echo 'Dans les temps';
            } elseif ($overall_status == 'behind') {
                echo 'En retard';
            } else {
                echo 'En cours';
            }
            ?>
        </div>
    </div>

    <div class="weight-values">
        <div class="weight-value-item">
            <div class="weight-value-label">Poids actuel</div>
            <div class="weight-value-number">
                <?php echo $current_weight ? number_format($current_weight, 1) : '-'; ?>
                <span class="weight-value-unit">kg</span>
            </div>
        </div>

        <div class="weight-arrow">
            <i class="fa fa-arrow-right"></i>
        </div>

        <div class="weight-value-item">
            <div class="weight-value-label">Poids cible</div>
            <div class="weight-value-number">
                <?php echo $target_weight ? number_format($target_weight, 1) : '-'; ?>
                <span class="weight-value-unit">kg</span>
            </div>
        </div>
    </div>

    <?php if ($weight_remaining !== null) { ?>
    <div class="weight-remaining">
        <div class="weight-remaining-text">
            <?php
            // Calculate difference WITH direction (not abs)
            $weight_diff = $current_weight - $target_weight;
            $total_change = $initial_weight ? abs($current_weight - $initial_weight) : 0;

            if ($goal_type == 'lose') {
                // Objectif = PERDRE du poids
                if ($weight_diff > 0.5) {
                    // Pas encore atteint
                    echo 'Encore à perdre';
                } elseif (abs($weight_diff) <= 0.5) {
                    // Objectif atteint (dans la marge de 0.5kg)
                    echo 'Objectif atteint !';
                } else {
                    // Dépassé (poids actuel < poids cible)
                    echo 'Objectif dépassé !';
                }
            } elseif ($goal_type == 'gain') {
                // Objectif = PRENDRE du poids
                if ($weight_diff < -0.5) {
                    // Pas encore atteint
                    echo 'À rattraper';
                } elseif (abs($weight_diff) <= 0.5) {
                    // Objectif atteint
                    echo 'Objectif atteint !';
                } else {
                    // Dépassé (poids actuel > poids cible)
                    echo 'Objectif dépassé !';
                }
            } else {
                echo 'Objectif maintenu';
            }
            ?>
        </div>
        <div class="weight-remaining-value">
            <?php
            if ($goal_type == 'lose') {
                if ($weight_diff > 0.5) {
                    // Pas atteint : afficher kg restant à perdre
                    echo number_format($weight_diff, 1) . ' kg restants';
                } elseif (abs($weight_diff) <= 0.5) {
                    // Atteint : afficher total perdu + différence exacte avec objectif
                    echo '🎉 ' . number_format($total_change, 1) . ' kg perdus';
                    if (abs($weight_diff) > 0) {
                        if ($weight_diff > 0) {
                            // Encore un peu à perdre (ex: 100kg pour objectif 99kg = +1kg)
                            echo '<br><small style="font-size:14px; color: #ff9800;">(encore ' . number_format($weight_diff, 1) . ' kg)</small>';
                        } else {
                            // Un peu en dessous (ex: 98kg pour objectif 99kg = -1kg)
                            echo '<br><small style="font-size:14px; color: #4caf50;">(' . number_format(abs($weight_diff), 1) . ' kg de moins)</small>';
                        }
                    }
                } else {
                    // Dépassé : afficher total perdu + excédent
                    $excess = abs($weight_diff);
                    echo '🎉 ' . number_format($total_change, 1) . ' kg perdus<br><small style="font-size:14px">(+' . number_format($excess, 1) . ' kg de plus)</small>';
                }
            } elseif ($goal_type == 'gain') {
                $weight_diff_gain = $target_weight - $current_weight; // Pour gain, on inverse
                if ($weight_diff_gain > 0.5) {
                    // Pas atteint : afficher kg restant à gagner
                    echo number_format($weight_diff_gain, 1) . ' kg restants';
                } elseif (abs($weight_diff_gain) <= 0.5) {
                    // Atteint : afficher total gagné + différence exacte avec objectif
                    echo '🎉 ' . number_format($total_change, 1) . ' kg gagnés';
                    if (abs($weight_diff_gain) > 0) {
                        if ($weight_diff_gain > 0) {
                            // Encore un peu à gagner
                            echo '<br><small style="font-size:14px; color: #ff9800;">(encore ' . number_format($weight_diff_gain, 1) . ' kg)</small>';
                        } else {
                            // Un peu au-dessus
                            echo '<br><small style="font-size:14px; color: #4caf50;">(' . number_format(abs($weight_diff_gain), 1) . ' kg de plus)</small>';
                        }
                    }
                } else {
                    // Dépassé : afficher total gagné + excédent
                    $excess = abs($weight_diff_gain);
                    echo '🎉 ' . number_format($total_change, 1) . ' kg gagnés<br><small style="font-size:14px">(+' . number_format($excess, 1) . ' kg de plus)</small>';
                }
            } else {
                echo '🎉';
            }
            ?>
        </div>
    </div>
    <?php } ?>

    <?php if ($current_weight && $target_weight) { ?>
    <div class="progress-gauge-container">
        <div class="progress-gauge-header">
            <div class="progress-gauge-label">Progression</div>
            <div class="progress-gauge-percent"><?php echo round($progress_percent); ?>%</div>
        </div>

        <!-- Graphique circulaire moderne -->
        <div class="progress-visual-container">
            <svg class="progress-circle-svg" viewBox="0 0 200 200">
                <defs>
                    <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#01807B;stop-opacity:1" />
                        <stop offset="100%" style="stop-color:#019d96;stop-opacity:1" />
                    </linearGradient>
                </defs>
                <circle class="progress-circle-bg" cx="100" cy="100" r="85" />
                <circle class="progress-circle-fill" cx="100" cy="100" r="85"
                        style="stroke-dashoffset: calc(534.07 - (534.07 * <?php echo round($progress_percent); ?>) / 100);" />
            </svg>
            <div class="progress-circle-text">
                <div class="progress-circle-number"><?php echo round($progress_percent); ?><span class="progress-percent-symbol">%</span></div>
                <div class="progress-circle-label">PROGRESSION</div>
            </div>
        </div>

        <div class="progress-gauge-bar">
            <div class="progress-gauge-fill" style="width: <?php echo round($progress_percent); ?>%;"></div>
        </div>
    </div>
    <?php } ?>

    <div class="weight-motivation-message <?php echo $overall_status; ?>">
        <?php echo $motivation_message; ?>
    </div>
</div>

<!-- Other Stats Cards -->
<div class="stats-grid">
    <div class="stat-card bmi">
        <div class="stat-icon">
            <i class="fa fa-heartbeat"></i>
        </div>
        <div class="stat-value"><?php echo $patient->latest_measurement && $patient->latest_measurement->bmi ? number_format($patient->latest_measurement->bmi, 1) : '-'; ?></div>
        <div class="stat-label">IMC</div>
    </div>

    <?php if ($weight_progress->weight_change !== null) { ?>
    <div class="stat-card progress">
        <div class="stat-icon">
            <i class="fa fa-area-chart"></i>
        </div>
        <div class="stat-value <?php echo $weight_progress->weight_change < 0 ? 'text-success' : ''; ?>">
            <?php echo ($weight_progress->weight_change > 0 ? '+' : '') . number_format($weight_progress->weight_change, 1); ?>
        </div>
        <div class="stat-label">Progression (kg)</div>
    </div>
    <?php } ?>
</div>

<!-- Hydration Card - Compact Version -->
<div class="hydration-card-compact">
    <div class="hydration-header-compact">
        <div class="hydration-title-compact">
            <i class="fa fa-tint"></i>
            Hydratation
        </div>
        <div class="hydration-goal-display">
            <span id="waterLevelText">0 ml</span> consommé / <span id="waterRemainingText">2000 ml</span> restant
        </div>
    </div>

    <div class="hydration-progress-bar">
        <div class="hydration-progress-fill" id="hydrationProgressBar" style="width: 0%"></div>
    </div>

    <div class="hydration-actions-compact">
        <!-- Custom Amount Section with Quick Buttons -->
        <div class="hydration-row">
            <div class="custom-input-section">
                <label class="compact-label">Quantité personnalisée</label>
                <input type="number"
                       id="customWaterAmount"
                       class="compact-input"
                       placeholder="Ex: 350"
                       min="1"
                       max="2000"
                       step="50">
            </div>

            <div class="quick-buttons-inline">
                <button class="quick-btn-glass" onclick="addWater(250)" title="250ml">
                    <div class="water-glass-small">
                        <div class="water-fill">
                            <div class="water-wave"></div>
                            <div class="water-wave" style="animation-delay: -1s;"></div>
                        </div>
                        <div class="water-cup-add">
                            <i class="fa fa-plus"></i>
                        </div>
                        <div class="water-amount">250ml</div>
                    </div>
                </button>
                <button class="quick-btn-glass" onclick="addWater(500)" title="500ml">
                    <div class="water-glass-medium">
                        <div class="water-fill">
                            <div class="water-wave"></div>
                            <div class="water-wave" style="animation-delay: -1s;"></div>
                        </div>
                        <div class="water-cup-add">
                            <i class="fa fa-plus"></i>
                        </div>
                        <div class="water-amount">500ml</div>
                    </div>
                </button>
                <button class="quick-btn-glass" onclick="addWater(750)" title="750ml">
                    <div class="water-glass-large">
                        <div class="water-fill">
                            <div class="water-wave"></div>
                            <div class="water-wave" style="animation-delay: -1s;"></div>
                        </div>
                        <div class="water-cup-add">
                            <i class="fa fa-plus"></i>
                        </div>
                        <div class="water-amount">750ml</div>
                    </div>
                </button>
                <button class="add-custom-btn-compact" onclick="addCustomWater()" title="Ajouter quantité personnalisée">
                    <i class="fa fa-plus"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- 7 derniers jours -->
    <div class="hydration-history-compact">
        <div class="history-title-compact">7 derniers jours</div>
        <div class="history-bars-compact" id="hydrationHistory">
            <!-- Will be filled by JavaScript -->
        </div>
    </div>
</div>

<!-- Activities Card - Compact & Fun -->
<div class="activities-card-compact">
    <div class="activities-header-compact">
        <div class="activities-title-compact">
            <i class="fa fa-heartbeat"></i>
            Activités Sportives
        </div>
    </div>

    <!-- Stats Row -->
    <div class="activities-stats-row">
        <div class="activity-stat-item">
            <div class="activity-stat-value" id="todayActivitiesCount">0</div>
            <div class="activity-stat-label">Activités</div>
        </div>
        <div class="activity-stat-item">
            <div class="activity-stat-value" id="todayMinutes">0</div>
            <div class="activity-stat-label">Minutes</div>
        </div>
        <div class="activity-stat-item">
            <div class="activity-stat-value" id="todayKcal">0</div>
            <div class="activity-stat-label">Kcal brûlées</div>
        </div>
    </div>

    <!-- Today's Activities List -->
    <div class="activities-list-compact" id="todayActivitiesList">
        <div class="no-activities-compact">
            <i class="fa fa-heartbeat"></i>
            Aucune activité enregistrée aujourd'hui
        </div>
    </div>

    <!-- Actions -->
    <div class="activities-actions-compact">
        <button class="btn-add-activity-compact" onclick="window.location.href='<?php echo site_url('dietetic/portal/activities'); ?>#add-activity'">
            <i class="fa fa-plus"></i>
            Ajouter une activité
        </button>
        <button class="btn-view-all-activities" onclick="window.location.href='<?php echo site_url('dietetic/portal/activities'); ?>'">
            <i class="fa fa-list"></i>
            Voir tout
        </button>
    </div>
</div>

<!-- Program Card -->
<?php if ($active_program) { ?>
<div class="program-card">
    <div class="program-header">
        <div class="program-title"><i class="fa fa-trophy"></i> <?php echo $active_program->program_name; ?></div>
        <div class="program-status">
            <i class="fa fa-circle"></i>
            Programme actif
        </div>
    </div>

    <div class="program-body">
        <div class="program-info-grid">
            <div class="info-item">
                <i class="fa fa-calendar-alt"></i>
                <div class="info-content">
                    <div class="info-label">Date de début</div>
                    <div class="info-value"><?php echo _d($active_program->start_date); ?></div>
                </div>
            </div>

            <?php if ($active_program->end_date) { ?>
            <div class="info-item">
                <i class="fa fa-calendar-check"></i>
                <div class="info-content">
                    <div class="info-label">Date de fin</div>
                    <div class="info-value"><?php echo _d($active_program->end_date); ?></div>
                </div>
            </div>
            <?php } ?>

            <?php if ($active_program->daily_calories) { ?>
            <div class="info-item">
                <i class="fa fa-fire"></i>
                <div class="info-content">
                    <div class="info-label">Calories quotidiennes</div>
                    <div class="info-value"><?php echo $active_program->daily_calories; ?> kcal</div>
                </div>
            </div>
            <?php } ?>

            <?php if ($active_program->daily_protein) { ?>
            <div class="info-item">
                <i class="fa fa-drumstick-bite"></i>
                <div class="info-content">
                    <div class="info-label">Protéines</div>
                    <div class="info-value"><?php echo $active_program->daily_protein; ?>g</div>
                </div>
            </div>
            <?php } ?>
        </div>

        <?php if ($active_program->objective) { ?>
        <div class="program-objective">
            <strong><i class="fa fa-bullseye"></i> Objectif</strong>
            <p><?php echo nl2br(htmlspecialchars($active_program->objective)); ?></p>
        </div>
        <?php } ?>

        <?php
        $this->load->model('dietetic/dietetic_meal_plans_model');
        $meal_plans = $this->dietetic_meal_plans_model->get_by_program($active_program->id);
        ?>

        <?php if (!empty($meal_plans)) { ?>
        <div class="meal-plans-section">
            <h5 class="section-title">
                <i class="fa fa-utensils"></i>
                Plans de repas
            </h5>

            <?php foreach ($meal_plans as $plan) { ?>
            <div class="meal-plan-item">
                <div class="meal-plan-name">
                    <i class="fa fa-calendar-week"></i>
                    <?php echo $plan->plan_name; ?> - Semaine <?php echo $plan->week_number; ?>
                </div>
                <div class="meal-plan-actions">
                    <a href="<?php echo site_url('dietetic/portal/meal_plan/' . $plan->id); ?>" class="btn-flat btn-flat-primary">
                        <i class="fa fa-eye"></i> Voir les détails
                    </a>
                    <a href="<?php echo site_url('dietetic/portal/download_meal_plan/' . $plan->id); ?>" class="btn-flat btn-flat-success">
                        <i class="fa fa-download"></i> Télécharger PDF
                    </a>
                </div>
            </div>
            <?php } ?>
        </div>
        <?php } ?>
    </div>
</div>
<?php } else { ?>
<div class="no-program-alert">
    <i class="fa fa-info-circle"></i>
    <p>Aucun programme actif pour le moment. Votre diététicien vous en assignera un prochainement.</p>
</div>
<?php } ?>

<!-- Row for Chart and Consultations -->
<div class="row">
    <div class="col-md-6">
        <div class="chart-card">
            <h4><i class="fa fa-chart-area"></i> Évolution du poids</h4>
            <canvas id="portalWeightChart" height="200"></canvas>
            <div style="margin-top: 20px; text-align: center;">
                <a href="<?php echo site_url('dietetic/portal/statistics'); ?>" class="btn-flat btn-flat-primary">
                    <i class="fa fa-area-chart"></i> Voir les statistiques détaillées
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="consultations-card">
            <div class="consultations-header">
                <h4><i class="fa fa-calendar-alt"></i> Prochains rendez-vous</h4>
            </div>
            <div class="consultations-body">
                <?php if (!empty($upcoming_consultations)) { ?>
                <div class="consultation-timeline">
                    <?php foreach ($upcoming_consultations as $consultation) { ?>
                    <div class="consultation-item">
                        <div class="consultation-dot"></div>
                        <div class="consultation-content">
                            <div class="consultation-date">
                                <i class="fa fa-clock"></i>
                                <?php echo _dt($consultation->consultation_date); ?>
                            </div>
                            <div class="consultation-type">
                                <?php echo ucfirst(str_replace('_', ' ', $consultation->consultation_type)); ?>
                            </div>
                            <?php if ($consultation->status == 'pending') { ?>
                            <span class="consultation-badge consultation-badge-pending">
                                <i class="fa fa-hourglass-half"></i>
                                En attente de validation
                            </span>
                            <?php } elseif ($consultation->status == 'rejected') { ?>
                            <span class="consultation-badge consultation-badge-rejected">
                                <i class="fa fa-ban"></i>
                                Refusée
                            </span>
                            <?php } elseif ($consultation->status == 'cancelled') { ?>
                            <span class="consultation-badge consultation-badge-cancelled">
                                <i class="fa fa-times-circle"></i>
                                Annulée
                            </span>
                            <?php } else { ?>
                            <span class="consultation-badge consultation-badge-scheduled">
                                <i class="fa fa-check-circle"></i>
                                Programmé
                            </span>
                            <?php } ?>
                        </div>
                    </div>
                    <?php } ?>
                </div>

                <div style="margin-top: 20px; text-align: center;">
                    <a href="<?php echo site_url('dietetic/portal/consultations'); ?>" class="btn-flat btn-flat-primary">
                        <i class="fa fa-list"></i> Voir tous les rendez-vous
                    </a>
                </div>
                <?php } else { ?>
                <div class="empty-consultations">
                    <i class="fa fa-calendar-times"></i>
                    <p>Aucun rendez-vous programmé</p>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<!-- Blog Carousel Section - Conseils -->
<?php if (!empty($blog_articles)) { ?>
<div class="blog-carousel-section">
    <div class="blog-carousel-header">
        <div class="blog-carousel-title">
            <i class="fa fa-file-text-o"></i>
            Conseils & Actualités
        </div>
        <a href="<?php echo site_url('dietetic/portal/blog'); ?>" class="blog-view-all">
            <span>Voir tout</span>
            <i class="fa fa-arrow-right"></i>
        </a>
    </div>

    <div class="blog-carousel-container">
        <div class="blog-carousel-track" id="blogCarouselTrack">
            <?php foreach ($blog_articles as $article) { ?>
                <a href="<?php echo site_url('dietetic/portal/blog_article/' . $article->slug); ?>" class="blog-card-carousel">
                    <?php if ($article->category && isset($article->category_details)) { ?>
                        <span class="blog-card-category">
                            <i class="fa <?php echo $article->category_details->icon; ?>"></i>
                            <?php echo htmlspecialchars($article->category_details->name); ?>
                        </span>
                    <?php } ?>

                    <div class="blog-card-title-carousel">
                        <?php echo htmlspecialchars($article->title); ?>
                    </div>

                    <div class="blog-card-footer-carousel">
                        <span>
                            <i class="fa fa-calendar"></i> <?php echo date('d M Y', strtotime($article->published_at)); ?>
                        </span>
                        <span>
                            <i class="fa fa-eye"></i> <?php echo $article->views_count; ?>
                        </span>
                    </div>
                </a>
            <?php } ?>
        </div>
    </div>

    <div class="blog-carousel-nav">
        <button class="blog-nav-btn" id="blogPrevBtn" onclick="blogCarouselPrev()">
            <i class="fa fa-chevron-left"></i>
        </button>
        <button class="blog-nav-btn" id="blogNextBtn" onclick="blogCarouselNext()">
            <i class="fa fa-chevron-right"></i>
        </button>
    </div>

    <div class="blog-carousel-dots" id="blogCarouselDots">
        <!-- Dots will be generated by JavaScript -->
    </div>
</div>
<?php } ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
$(function() {
    <?php if (!empty($weight_evolution)) { ?>
        var labels = [<?php foreach ($weight_evolution as $m) { echo '"' . _d($m->measurement_date) . '",'; } ?>];
        var weights = [<?php foreach ($weight_evolution as $m) { echo $m->weight . ','; } ?>];
        var bmis = [<?php foreach ($weight_evolution as $m) { echo $m->bmi . ','; } ?>];

        if (typeof dietetic_portal !== 'undefined') {
            dietetic_portal.loadWeightChart('portalWeightChart', weights, bmis, labels);
        }
    <?php } ?>

    // Load hydration data on page load
    loadHydrationData();
});

// Hydration tracking variables
let hydrationData = {
    today_total: 0,
    daily_goal: 2000,
    percentage: 0,
    history: []
};

// Load hydration data
async function loadHydrationData() {
    try {
        const response = await fetch('<?php echo site_url('dietetic/portal/api_get_hydration_data'); ?>');
        const data = await response.json();

        if (data.success) {
            hydrationData = data;
            updateHydrationDisplay();
        }
    } catch (error) {
        console.error('Error loading hydration data:', error);
    }
}

// Update water level display (compact version)
function updateHydrationDisplay() {
    const waterLevelText = document.getElementById('waterLevelText');
    const waterRemainingText = document.getElementById('waterRemainingText');
    const progressBar = document.getElementById('hydrationProgressBar');

    if (!waterLevelText || !waterRemainingText || !progressBar) {
        console.error('Hydration display elements not found');
        return;
    }

    // Calculate remaining
    const remaining = Math.max(0, hydrationData.daily_goal - hydrationData.today_total);

    // Update progress bar width (max 100%)
    const widthPercentage = Math.min(100, hydrationData.percentage);
    progressBar.style.width = widthPercentage + '%';

    // Update text
    waterLevelText.textContent = hydrationData.today_total + ' ml';
    waterRemainingText.textContent = remaining + ' ml';

    // Update history
    updateHydrationHistory();
}

// Update history bars with French days
function updateHydrationHistory() {
    const historyContainer = document.getElementById('hydrationHistory');

    if (!historyContainer) {
        return;
    }

    if (!hydrationData.history || hydrationData.history.length === 0) {
        historyContainer.innerHTML = '<div style="text-align: center; color: #6c757d; padding: 20px; grid-column: 1 / -1;">Aucun historique</div>';
        return;
    }

    // French day names mapping
    const frenchDays = {
        'Mon': 'Lun',
        'Tue': 'Mar',
        'Wed': 'Mer',
        'Thu': 'Jeu',
        'Fri': 'Ven',
        'Sat': 'Sam',
        'Sun': 'Dim'
    };

    let html = '';
    hydrationData.history.forEach(day => {
        const dayFr = frenchDays[day.day_name] || day.day_name;
        html += `
            <div class="history-bar-compact">
                <div class="history-bar-fill-compact">
                    <div class="history-bar-value-compact" style="height: ${day.percentage}%"></div>
                </div>
                <div class="history-day-compact">${dayFr}</div>
            </div>
        `;
    });

    historyContainer.innerHTML = html;
}

// Add water (quick buttons)
async function addWater(amount) {
    const btn = event.target.closest('.quick-btn-glass');
    if (!btn) {
        console.error('Button not found');
        return;
    }

    const waterGlass = btn.querySelector('[class^="water-glass-"]');
    const addIcon = btn.querySelector('.water-cup-add i');
    const originalIconClass = addIcon.className;

    // Disable button and show loading
    btn.disabled = true;
    addIcon.className = 'fa fa-spinner fa-spin';

    try {
        const formData = new FormData();
        formData.append('quantity_ml', amount);
        formData.append('<?php echo $this->security->get_csrf_token_name(); ?>', '<?php echo $this->security->get_csrf_hash(); ?>');

        const response = await fetch('<?php echo site_url('dietetic/portal/api_add_hydration'); ?>', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            // Update local data
            hydrationData.today_total = data.new_total;
            hydrationData.percentage = data.percentage;

            // Animate update
            updateHydrationDisplay();

            // Show success feedback with animation
            addIcon.className = 'fa fa-check';
            waterGlass.style.transform = 'scale(1.1)';
            waterGlass.style.transition = 'transform 0.3s';

            setTimeout(() => {
                waterGlass.style.transform = 'scale(1)';
                addIcon.className = originalIconClass;
                btn.disabled = false;
            }, 1500);
        } else {
            alert('Erreur: ' + (data.message || 'Impossible d\'ajouter'));
            addIcon.className = originalIconClass;
            btn.disabled = false;
        }
    } catch (error) {
        console.error('Error adding water:', error);
        alert('Erreur lors de l\'ajout');
        addIcon.className = originalIconClass;
        btn.disabled = false;
    }
}

// Add custom amount
async function addCustomWater() {
    const input = document.getElementById('customWaterAmount');
    const amount = parseInt(input.value);

    if (!amount || amount <= 0 || amount > 2000) {
        alert('Veuillez entrer une quantité valide (1-2000ml)');
        return;
    }

    const btn = event.target.closest('.add-custom-btn-compact');
    if (!btn) {
        console.error('Button not found');
        return;
    }

    const originalHtml = btn.innerHTML;

    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i>';

    try {
        const formData = new FormData();
        formData.append('quantity_ml', amount);
        formData.append('<?php echo $this->security->get_csrf_token_name(); ?>', '<?php echo $this->security->get_csrf_hash(); ?>');

        const response = await fetch('<?php echo site_url('dietetic/portal/api_add_hydration'); ?>', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            // Update local data
            hydrationData.today_total = data.new_total;
            hydrationData.percentage = data.percentage;

            // Animate update
            updateHydrationDisplay();

            // Reset input
            input.value = '';

            // Show success feedback
            btn.innerHTML = '<i class="fa fa-check"></i>';
            setTimeout(() => {
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            }, 1500);
        } else {
            alert('Erreur: ' + (data.message || 'Impossible d\'ajouter'));
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        }
    } catch (error) {
        console.error('Error adding custom water:', error);
        alert('Erreur lors de l\'ajout');
        btn.innerHTML = originalHtml;
        btn.disabled = false;
    }
}

// ============================================
// ACTIVITIES TRACKING - Dashboard Widget
// ============================================

// Load today's activities on page load
$(document).ready(function() {
    loadTodayActivities();
});

async function loadTodayActivities() {
    try {
        const response = await fetch('<?php echo site_url('dietetic/portal/api_get_today_activities'); ?>');
        const data = await response.json();

        if (data.success) {
            updateActivitiesDisplay(data);
        }
    } catch (error) {
        console.error('Error loading activities:', error);
    }
}

function updateActivitiesDisplay(data) {
    // Update stats
    $('#todayActivitiesCount').text(data.count || 0);
    $('#todayMinutes').text(data.total_minutes || 0);
    $('#todayKcal').text(Math.round(data.total_kcal || 0));

    // Update activities list
    const listContainer = $('#todayActivitiesList');

    if (!data.activities || data.activities.length === 0) {
        listContainer.html(`
            <div class="no-activities-compact">
                <i class="fa fa-heartbeat"></i>
                Aucune activité enregistrée aujourd'hui
            </div>
        `);
        return;
    }

    // Display up to 3 most recent activities
    const activitiesToShow = data.activities.slice(0, 3);
    let html = '';

    activitiesToShow.forEach(activity => {
        const icon = getActivityIcon(activity.category);
        html += `
            <div class="activity-item-compact">
                <div class="activity-item-left">
                    <div class="activity-icon-compact">
                        <i class="fa ${icon}"></i>
                    </div>
                    <div class="activity-info-compact">
                        <div class="activity-name-compact">${activity.activity_name}</div>
                        <div class="activity-duration-compact">
                            <i class="fa fa-clock-o"></i>
                            ${activity.duration_minutes} min
                        </div>
                    </div>
                </div>
                <div class="activity-kcal-compact">
                    <i class="fa fa-fire"></i>
                    ${Math.round(activity.kcal_burned)}
                </div>
            </div>
        `;
    });

    listContainer.html(html);
}

function getActivityIcon(category) {
    const icons = {
        'Cardio': 'fa-running',
        'Musculation': 'fa-dumbbell',
        'Sports collectifs': 'fa-futbol-o',
        'Arts martiaux': 'fa-hand-rock-o',
        'Yoga/Étirements': 'fa-child',
        'Danse': 'fa-music',
        'Autres': 'fa-heartbeat'
    };

    return icons[category] || 'fa-heartbeat';
}

// ============================================
// BLOG CAROUSEL - Responsive navigation
// ============================================

let blogCurrentIndex = 0;
let blogCardsPerView = 3;

// Calculate how many cards to show based on screen size
function updateBlogCardsPerView() {
    const width = window.innerWidth;
    if (width < 576) {
        blogCardsPerView = 1;
    } else if (width < 992) {
        blogCardsPerView = 2;
    } else {
        blogCardsPerView = 3;
    }
}

function initBlogCarousel() {
    updateBlogCardsPerView();

    const track = document.getElementById('blogCarouselTrack');
    const dotsContainer = document.getElementById('blogCarouselDots');

    if (!track || !dotsContainer) {
        return;
    }

    const totalCards = track.children.length;
    const totalPages = Math.ceil(totalCards / blogCardsPerView);

    // Generate dots
    dotsContainer.innerHTML = '';
    for (let i = 0; i < totalPages; i++) {
        const dot = document.createElement('div');
        dot.className = 'blog-carousel-dot' + (i === 0 ? ' active' : '');
        dot.onclick = () => blogGoToPage(i);
        dotsContainer.appendChild(dot);
    }

    updateBlogCarousel();
}

function blogCarouselNext() {
    const track = document.getElementById('blogCarouselTrack');
    if (!track) return;

    const totalCards = track.children.length;
    const totalPages = Math.ceil(totalCards / blogCardsPerView);

    if (blogCurrentIndex < totalPages - 1) {
        blogCurrentIndex++;
        updateBlogCarousel();
    }
}

function blogCarouselPrev() {
    if (blogCurrentIndex > 0) {
        blogCurrentIndex--;
        updateBlogCarousel();
    }
}

function blogGoToPage(pageIndex) {
    blogCurrentIndex = pageIndex;
    updateBlogCarousel();
}

function updateBlogCarousel() {
    const track = document.getElementById('blogCarouselTrack');
    const prevBtn = document.getElementById('blogPrevBtn');
    const nextBtn = document.getElementById('blogNextBtn');
    const dots = document.querySelectorAll('.blog-carousel-dot');

    if (!track) return;

    const totalCards = track.children.length;
    const totalPages = Math.ceil(totalCards / blogCardsPerView);

    // Calculate the offset
    const cardWidth = 100 / blogCardsPerView;
    const offset = -(blogCurrentIndex * 100);
    track.style.transform = `translateX(${offset}%)`;

    // Update button states
    if (prevBtn) prevBtn.disabled = blogCurrentIndex === 0;
    if (nextBtn) nextBtn.disabled = blogCurrentIndex >= totalPages - 1;

    // Update dots
    dots.forEach((dot, index) => {
        if (index === blogCurrentIndex) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

// Initialize on page load and window resize
$(document).ready(function() {
    initBlogCarousel();
});

window.addEventListener('resize', function() {
    updateBlogCardsPerView();
    initBlogCarousel();
});
</script>

<?php $this->load->view('portal/includes/portal_footer'); ?>
